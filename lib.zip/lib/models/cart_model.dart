class CartModel {

  final Map ikan;
  int jumlah;

  CartModel({

    required this.ikan,
    required this.jumlah,
  });
}