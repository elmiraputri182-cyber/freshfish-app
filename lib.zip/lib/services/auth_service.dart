import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {

  static const String baseUrl =
      "http://192.168.1.15/appfreashfish/freashfish_api";

  static Future<bool> register(
    String username,
    String password,
    String role,
    String namaLengkap,
    String noTelp,
    String alamat,
  ) async {

    try {

      final response = await http.post(

        Uri.parse("$baseUrl/register.php"),

        body: {

          "username": username,
          "password": password,
          "role": role,
          "nama_lengkap": namaLengkap,
          "no_telp": noTelp,
          "alamat": alamat,

        },
      );

      print("STATUS CODE = ${response.statusCode}");
      print("RESPONSE = ${response.body}");

      final data = jsonDecode(response.body);

      print("DATA = $data");

      return true;

    } catch (e) {

      print("ERROR REGISTER = $e");

      return false;
    }
  }

  static Future<Map<String, dynamic>> login(
  String username,
  String password,
) async {

  try {

    print("BASE URL = $baseUrl");

    final url =
        Uri.parse("$baseUrl/login.php");

    print("URL = $url");

    final response = await http.post(

      url,

      body: {

        "username": username,
        "password": password,

      },

    );

    print("STATUS = ${response.statusCode}");
    print("BODY = ${response.body}");

    return jsonDecode(response.body);

  } catch (e) {

    print("ERROR LOGIN = $e");

    return {
      "success": false,
    };

  }

}
}