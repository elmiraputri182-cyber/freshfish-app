import 'dart:convert';
import 'package:http/http.dart' as http;

class UpdateStatusService {

  static const String baseUrl =
      "http://192.168.1.15/appfreashfish/freashfish_api/update_status_pesanan.php";

  static Future<bool> updateStatus(

      String idPesanan,
      String status,

      ) async {

    final response = await http.post(

      Uri.parse("$baseUrl/update_status_pesanan.php"),

      body: {

        "id_pesanan": idPesanan,
        "status": status,

      },

    );

    final hasil = jsonDecode(response.body);

    return hasil["success"] == true;

  }

}