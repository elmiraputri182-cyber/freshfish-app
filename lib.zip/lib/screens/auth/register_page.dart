import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/auth_service.dart';
import 'login_page.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {

  final TextEditingController username =
      TextEditingController();

  final TextEditingController password =
      TextEditingController();

  final TextEditingController namaLengkap =
      TextEditingController();

  final TextEditingController noTelp =
      TextEditingController();

  final TextEditingController alamat =
      TextEditingController();

  String role = "pembeli";

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,

      body: SafeArea(

        child: Stack(

          children: [

            // dekorasi atas
            Positioned(
              top: -70,
              right: -60,
              child: Container(
                height: 220,
                width: 220,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.08),
                  shape: BoxShape.circle,
                ),
              ),
            ),

            // dekorasi bawah
            Positioned(
              bottom: -100,
              left: -80,
              child: Container(
                height: 260,
                width: 260,
                decoration: BoxDecoration(
                  color: Colors.lightBlue.withOpacity(0.08),
                  shape: BoxShape.circle,
                ),
              ),
            ),

            SingleChildScrollView(

              padding: const EdgeInsets.symmetric(
                horizontal: 30,
                vertical: 30,
              ),

              child: Column(

                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  const SizedBox(height: 20),

                  // logo
                  Center(
                    child: Container(
                      height: 110,
                      width: 110,

                      decoration: BoxDecoration(

                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF2196F3),
                            Color(0xFF03A9F4),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),

                        borderRadius:
                            BorderRadius.circular(30),

                        boxShadow: [

                          BoxShadow(
                            color: Colors.blue
                                .withOpacity(0.25),
                            blurRadius: 25,
                            offset: const Offset(0, 10),
                          ),

                        ],
                      ),

                      child: const Icon(
                        Icons.person_add_alt_1_rounded,
                        color: Colors.white,
                        size: 55,
                      ),
                    ),
                  ),

                  const SizedBox(height: 35),

                  Text(
                    "Buat Akun Baru 👋",
                    style: GoogleFonts.poppins(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF1565C0),
                    ),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    "Daftar untuk mulai menggunakan aplikasi FreshFish",
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      color: Colors.blueGrey,
                      height: 1.5,
                    ),
                  ),

                  const SizedBox(height: 30),

                  // username
                  buildTextField(
                    controller: username,
                    hint: "Username",
                    icon: Icons.person,
                  ),

                  const SizedBox(height: 18),

                  // password
                  buildTextField(
                    controller: password,
                    hint: "Password",
                    icon: Icons.lock,
                    obscure: true,
                  ),

                  const SizedBox(height: 18),

                  // role
                  Container(

                    padding: const EdgeInsets.symmetric(
                      horizontal: 15,
                    ),

                    decoration: BoxDecoration(
                      color: Colors.blue
                          .withOpacity(0.05),

                      borderRadius:
                          BorderRadius.circular(18),
                    ),

                    child: DropdownButton<String>(

                      value: role,

                      isExpanded: true,

                      underline: const SizedBox(),

                      items: const [

                        DropdownMenuItem(
                          value: "pembeli",
                          child: Text("Pembeli"),
                        ),

                        DropdownMenuItem(
                          value: "agen",
                          child: Text("Agen"),
                        ),

                      ],

                      onChanged: (value){

                        setState(() {
                          role = value!;
                        });

                      },
                    ),
                  ),

                  const SizedBox(height: 18),

                  // nama lengkap
                  buildTextField(
                    controller: namaLengkap,
                    hint: "Nama Lengkap",
                    icon: Icons.badge,
                  ),

                  const SizedBox(height: 18),

                  // no telepon
                  buildTextField(
                    controller: noTelp,
                    hint: "Nomor Telepon",
                    icon: Icons.phone,
                  ),

                  const SizedBox(height: 18),

                  // alamat
                  buildTextField(
                    controller: alamat,
                    hint: "Alamat",
                    icon: Icons.location_on,
                    maxLines: 3,
                  ),

                  const SizedBox(height: 35),

                  // tombol register
                  SizedBox(

                    width: double.infinity,
                    height: 58,

                    child: ElevatedButton(

                      style: ElevatedButton.styleFrom(

                        backgroundColor: Colors.blue,
                        elevation: 8,

                        shadowColor:
                            Colors.blue.withOpacity(0.35),

                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(18),
                        ),
                      ),

                      onPressed: () async {

                        print("TOMBOL REGISTER DIKLIK");

                        bool success = await AuthService.register(

                          username.text,
                          password.text,
                          role,
                          namaLengkap.text,
                          noTelp.text,
                          alamat.text,

                        );

                        print("HASIL REGISTER = $success");

                        if (!mounted) return;

                        if(success){

                          ScaffoldMessenger.of(context).showSnackBar(

                            const SnackBar(
                              content: Text("Register berhasil"),
                            ),
                          );

                          Navigator.pushReplacement(

                            context,

                            MaterialPageRoute(
                              builder: (_) => const LoginPage(),
                            ),
                          );

                        }else{

                          ScaffoldMessenger.of(context).showSnackBar(

                            const SnackBar(
                              content: Text("Register gagal"),
                            ),
                          );
                        }
                      },

                      child: Text(

                        "REGISTER",

                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 25),

                  // login
                  Row(

                    mainAxisAlignment:
                        MainAxisAlignment.center,

                    children: [

                      Text(
                        "Sudah punya akun?",
                        style: GoogleFonts.poppins(
                          color: Colors.grey,
                        ),
                      ),

                      TextButton(

                        onPressed: () {

                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  const LoginPage(),
                            ),
                          );
                        },

                        child: Text(
                          "Login",
                          style: GoogleFonts.poppins(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildTextField({

    required TextEditingController controller,
    required String hint,
    required IconData icon,

    bool obscure = false,
    int maxLines = 1,

  }) {

    return TextField(

      controller: controller,
      obscureText: obscure,
      maxLines: maxLines,

      style: GoogleFonts.poppins(),

      decoration: InputDecoration(

        hintText: hint,
        hintStyle: GoogleFonts.poppins(),

        prefixIcon: Icon(icon),

        filled: true,
        fillColor: Colors.blue.withOpacity(0.05),

        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}