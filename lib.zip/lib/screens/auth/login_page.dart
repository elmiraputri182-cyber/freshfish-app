import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/auth_service.dart';
import '../pembeli/home_page.dart';
import 'register_page.dart';
import '../agen/dashboard_agen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../admin/admin_dashboard_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  void login() async {

  final response = await AuthService.login(
    usernameController.text,
    passwordController.text,
  );
  print(response);
  if (!mounted) return;

  if (response["success"] == true) {
    final prefs =
    await SharedPreferences.getInstance();

      await prefs.setString(
      "id_user",
      response["data"]["id_user"].toString(),
    );

    if (response["data"]["id_agen"] != null) {

      await prefs.setString(
        "id_agen",
        response["data"]["id_agen"].toString(),
      );

    }

    await prefs.setString(
      "nama",
      response["data"]["nama"] ?? "",
    );

    await prefs.setString(
      "username",
      response["data"]["username"] ?? "",
    );

    await prefs.setString(
      "no_hp",
      response["data"]["no_hp"] ?? "",
    );

    await prefs.setString(
      "alamat",
      response["data"]["alamat"] ?? "",
    );
    String role =
    response["role"];

    print("ROLE = $role");

if (role == "admin") {

  Navigator.pushReplacement(

    context,

    MaterialPageRoute(
      builder: (_) =>
          const AdminDashboardPage(),
    ),
  );

} else if (role == "agen") {

  Navigator.pushReplacement(

    context,

    MaterialPageRoute(
      builder: (_) =>
          const DashboardAgen(),
    ),
  );

} else {

  Navigator.pushReplacement(

    context,

    MaterialPageRoute(
      builder: (_) =>
          const HomePage(),
    ),
  );
}

  } else {

    ScaffoldMessenger.of(context).showSnackBar(

      SnackBar(

        backgroundColor: Colors.red,

        content: Text(
          "Login gagal",
          style: GoogleFonts.poppins(),
        ),
      ),
    );
  }
}

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,

      body: SafeArea(
        child: Stack(
          children: [

            // dekorasi atas
            Positioned(
              top: -70,
              right: -60,
              child: Container(
                height: 220,
                width: 220,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.08),
                  shape: BoxShape.circle,
                ),
              ),
            ),

            // dekorasi bawah
            Positioned(
              bottom: -100,
              left: -80,
              child: Container(
                height: 260,
                width: 260,
                decoration: BoxDecoration(
                  color: Colors.lightBlue.withOpacity(0.08),
                  shape: BoxShape.circle,
                ),
              ),
            ),

            SingleChildScrollView(
              padding: const EdgeInsets.symmetric(
                horizontal: 30,
                vertical: 40,
              ),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  const SizedBox(height: 40),

                  // logo
                  Center(
                    child: Container(
                      height: 120,
                      width: 120,

                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF2196F3),
                            Color(0xFF03A9F4),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),

                        borderRadius: BorderRadius.circular(35),

                        boxShadow: [
                          BoxShadow(
                            color: Colors.blue.withOpacity(0.25),
                            blurRadius: 25,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),

                      child: const Icon(
                        Icons.set_meal_rounded,
                        color: Colors.white,
                        size: 60,
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  Text(
                    "Selamat Datang 👋",
                    style: GoogleFonts.poppins(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF1565C0),
                    ),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    "Masuk untuk melanjutkan ke aplikasi FreshFish",
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      color: Colors.blueGrey,
                      height: 1.5,
                    ),
                  ),

                  const SizedBox(height: 35),

                  // username
                  TextField(
                    controller: usernameController,

                    style: GoogleFonts.poppins(),

                    decoration: InputDecoration(
                      hintText: "Username",
                      hintStyle: GoogleFonts.poppins(),

                      prefixIcon: const Icon(Icons.person),

                      filled: true,
                      fillColor: Colors.blue.withOpacity(0.05),

                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // password
                  TextField(
                    controller: passwordController,
                    obscureText: true,

                    style: GoogleFonts.poppins(),

                    decoration: InputDecoration(
                      hintText: "Password",
                      hintStyle: GoogleFonts.poppins(),

                      prefixIcon: const Icon(Icons.lock),

                      filled: true,
                      fillColor: Colors.blue.withOpacity(0.05),

                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(height: 35),

                  // tombol login
                  SizedBox(
                    width: double.infinity,
                    height: 58,

                    child: ElevatedButton(

                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        elevation: 8,

                        shadowColor: Colors.blue.withOpacity(0.35),

                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                        ),
                      ),

                      onPressed: login,

                      child: Text(
                        "LOGIN",
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 25),

                  // register
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      Text(
                        "Belum punya akun?",
                        style: GoogleFonts.poppins(
                          color: Colors.grey,
                        ),
                      ),

                      TextButton(
                        onPressed: () {

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const RegisterPage(),
                            ),
                          );

                        },

                        child: Text(
                          "Register",
                          style: GoogleFonts.poppins(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}