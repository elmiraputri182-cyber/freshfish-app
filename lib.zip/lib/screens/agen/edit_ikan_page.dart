import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class EditIkanPage extends StatefulWidget {
  final dynamic ikan;
  final VoidCallback onSuccess;

  const EditIkanPage({super.key, required this.ikan, required this.onSuccess});

  @override
  State<EditIkanPage> createState() => _EditIkanPageState();
}

class _EditIkanPageState extends State<EditIkanPage> {
  File? imageFile;
  late TextEditingController nama;
  late TextEditingController jumlah;
  late TextEditingController harga;

  String kategori = "Ikan Laut";
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    nama = TextEditingController(text: widget.ikan["nama_ikan"]);
    jumlah = TextEditingController(text: widget.ikan["jumlah"]);
    harga = TextEditingController(text: widget.ikan["harga"]);
    kategori = widget.ikan["kategori"] ?? "Ikan Laut";
  }

  @override
  void dispose() {
    nama.dispose();
    jumlah.dispose();
    harga.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        imageFile = File(pickedFile.path);
      });
    }
  }

  Future<void> _submitEdit() async {
    if (nama.text.isEmpty ||
        jumlah.text.isEmpty ||
        harga.text.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Semua field harus diisi")));
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      var request = http.MultipartRequest(
        "POST",
        Uri.parse(
          "http://192.168.1.15/appfreashfish/freashfish_api/update_ikan.php",
        ),
      );

      request.fields["id_ikan"] = widget.ikan["id_ikan"];
      request.fields["nama_ikan"] = nama.text;
      request.fields["kategori"] = kategori;
      request.fields["jumlah"] = jumlah.text;
      request.fields["harga"] = harga.text;
      request.fields["status_tersedia"] = widget.ikan["status_tersedia"];

      if (imageFile != null) {
        request.files.add(
          await http.MultipartFile.fromPath("foto_ikan", imageFile!.path),
        );
      }

     var response = await request.send();

    var responseData =
        await response.stream.bytesToString();

    print("RESPONSE EDIT = ");
    print(responseData);

    final data =
        jsonDecode(responseData);

      if (!mounted) return;

      if (data["success"] == true) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text("Data berhasil diupdate")));

        widget.onSuccess();
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data["message"] ?? "Gagal mengupdate data")),
        );
      }
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Widget _buildField(TextEditingController controller, String hint) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
      title: Text(
        "Edit Ikan",
        style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // FOTO
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                height: 150,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: imageFile != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: kIsWeb
                            ? Image.network(imageFile!.path, fit: BoxFit.cover)
                            : Image.file(imageFile!, fit: BoxFit.cover),
                      )
                    : widget.ikan["foto_ikan"] != null &&
                          widget.ikan["foto_ikan"] != ""
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: Image.network(
                          "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${widget.ikan["foto_ikan"]}",
                          fit: BoxFit.cover,
                        ),
                      )
                    : const Icon(Icons.image, size: 50),
              ),
            ),
            const SizedBox(height: 20),
            _buildField(nama, "Nama Ikan"),
            const SizedBox(height: 15),
            Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(15),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: DropdownButton<String>(
  value: kategori,
  isExpanded: true,
  underline: const SizedBox(),

  items: const [

    DropdownMenuItem(
      value: "Ikan Laut",
      child: Text("Ikan Laut"),
    ),

    DropdownMenuItem(
      value: "Ikan Tawar",
      child: Text("Ikan Tawar"),
    ),

    DropdownMenuItem(
      value: "Udang",
      child: Text("Udang"),
    ),

    DropdownMenuItem(
      value: "Kerang",
      child: Text("Kerang"),
    ),
  ],

  onChanged: (value) {

    setState(() {

      kategori = value!;

    });

  },
),
            ),
            const SizedBox(height: 15),
            _buildField(jumlah, "Jumlah"),
            const SizedBox(height: 15),
            _buildField(harga, "Harga"),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text("Batal", style: GoogleFonts.poppins()),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          onPressed: isLoading ? null : _submitEdit,
          child: isLoading
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2,
                  ),
                )
              : Text(
                  "Simpan",
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
        ),
      ],
    );
  }
}
