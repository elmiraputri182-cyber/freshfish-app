import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

class LaporanAgenPage extends StatefulWidget {
  const LaporanAgenPage({super.key});

  @override
  State<LaporanAgenPage> createState() =>
      _LaporanAgenPageState();
}

class _LaporanAgenPageState
    extends State<LaporanAgenPage> {

      final rupiah = NumberFormat.currency(
        locale: 'id_ID',
        symbol: 'Rp ',
        decimalDigits: 0,
      );

  String filter = "Bulanan";

  int totalPesanan = 0;
  int totalPemasukan = 0;

  List laporan = [];
  
  bool isLoading = true;

  @override
void initState() {
  super.initState();
  getLaporan();
}
  Future<void> getLaporan() async {

  try {

    final pref =
        await SharedPreferences.getInstance();

    final idUser =
        pref.getString("id_user") ?? "";

    final response =
        await http.get(

      Uri.parse(
        "http://192.168.1.15/appfreashfish/freashfish_api/get_laporan_agen.php?id_user=$idUser&filter=$filter",
      ),
    );

    final data =
        jsonDecode(response.body);

    print(data);

    if (data["success"] == true) {

      setState(() {

        totalPesanan =
            int.parse(
              data["total_pesanan"].toString(),
            );

        totalPemasukan =
            int.parse(
              data["total_pemasukan"].toString(),
            );

        laporan =
            data["data"];

        isLoading = false;
      });
    }

  } catch (e) {

    print(e);

    setState(() {

      isLoading = false;

    });

  }
}

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xFFF8FBFF),

      appBar: AppBar(

        title: Text(
          "Laporan Penjualan",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
          ),
        ),

        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),

      body: SingleChildScrollView(

        padding:
            const EdgeInsets.all(20),

        child: Column(

          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [

            Text(
              "Filter Laporan",
              style: GoogleFonts.poppins(
                fontWeight:
                    FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            Container(

              padding:
                  const EdgeInsets.symmetric(
                horizontal: 15,
              ),

              decoration: BoxDecoration(

                color: Colors.white,

                borderRadius:
                    BorderRadius.circular(15),

                border: Border.all(
                  color: Colors.grey.shade300,
                ),
              ),

              child: 
              DropdownButtonFormField<String>(

                value: filter,

                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),

                items: const [

                  DropdownMenuItem(
                    value: "mingguan",
                    child: Text("Mingguan"),
                  ),

                  DropdownMenuItem(
                    value: "Bulanan",
                    child: Text("Bulanan"),
                  ),

                  DropdownMenuItem(
                    value: "tahunan",
                    child: Text("Tahunan"),
                  ),
                ],

                onChanged: (value) {

                  setState(() {

                    filter = value!;

                    isLoading = true;

                  });

                  getLaporan();
                },
              ),
            ),

            const SizedBox(height: 25),

            Text(
              "Ringkasan",
              style: GoogleFonts.poppins(
                fontWeight:
                    FontWeight.bold,
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 15),

            Row(

              children: [

                Expanded(
                  child: buildCard(
                    "Total Pesanan",
                    "$totalPesanan",
                    Colors.orange,
                    Icons.shopping_cart,
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: buildCard(
                    "Pemasukan",
                    rupiah.format(totalPemasukan),
                    Colors.green,
                    Icons.payments,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            Text(

              "Daftar Transaksi",

              style: GoogleFonts.poppins(

                fontWeight: FontWeight.bold,

                fontSize: 18,
              ),
            ),
             
            if (isLoading)
              const Center(
                child: CircularProgressIndicator(),
              )
            else if (laporan.isEmpty)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    "Belum ada transaksi",
                  ),
                ),
              )
            else
              ListView.builder(

                shrinkWrap: true,

                physics:
                    const NeverScrollableScrollPhysics(),

                itemCount:
                    laporan.length,

                itemBuilder:
                    (context,index){

                  final item =
                      laporan[index];

                  return Card(

                    margin:
                        const EdgeInsets.only(
                      bottom: 12,
                    ),

                    child: ListTile(

                      title: Text(

                        "Pesanan #${item["id_pesanan"]}",

                        style:
                            GoogleFonts.poppins(
                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),

                      subtitle: Column(

                        crossAxisAlignment:
                            CrossAxisAlignment
                                .start,

                        children: [

                          Text(
                            "Jumlah : ${item["jumlah_kg"]} Kg",
                          ),

                          Text(
                            "Pembayaran : ${item["metode_pembayaran"]}",
                          ),

                          Text(
                            "Tanggal : ${item["tanggal"]}",
                          ),
                        ],
                      ),

                      trailing: Text(

                        rupiah.format(
                          int.tryParse(item["total_harga"].toString()) ?? 0,
                        ),

                        style:
                            GoogleFonts.poppins(

                          color: Colors.green,

                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                },
            ),

            const SizedBox(height: 15),


            const SizedBox(height: 25),

            SizedBox(

              width: double.infinity,

              child: ElevatedButton.icon(

                onPressed: () {

                  /// Nanti cetak PDF

                },

                icon: const Icon(
                  Icons.picture_as_pdf,
                ),

                label: const Text(
                  "Cetak PDF",
                ),

                style:
                    ElevatedButton.styleFrom(

                  backgroundColor:
                      Colors.red,

                  foregroundColor:
                      Colors.white,

                  padding:
                      const EdgeInsets
                          .symmetric(
                    vertical: 15,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildCard(
    String title,
    String value,
    Color color,
    IconData icon,
  ) {
    return Container(

      padding:
          const EdgeInsets.all(15),

      decoration: BoxDecoration(

        color: Colors.white,

        borderRadius:
            BorderRadius.circular(20),

        boxShadow: [

          BoxShadow(

            color:
                Colors.black.withOpacity(
              0.05,
            ),

            blurRadius: 10,
          ),
        ],
      ),

      child: Column(

        children: [

          Icon(
            icon,
            color: color,
            size: 35,
          ),

          const SizedBox(height: 10),

          Text(
            title,
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 8),

          Text(
            value,
            style:
                GoogleFonts.poppins(

              color: color,

              fontWeight:
                  FontWeight.bold,

              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }
}