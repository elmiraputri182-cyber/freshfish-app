import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../services/update_status_service.dart';
import 'detail_pesanan_page.dart';
import 'package:intl/intl.dart';


class PesananMasukPage extends StatefulWidget {
  const PesananMasukPage({super.key});

  @override
  State<PesananMasukPage> createState() =>
      _PesananMasukPageState();
}

class _PesananMasukPageState
    extends State<PesananMasukPage> {

  final rupiah = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  List pesanan = [];

  bool isLoading = true;

  Future<void> getPesanan() async {

    final pref = await SharedPreferences.getInstance();

    final idAgen = pref.getString("id_user") ?? "";

    print("ID AGEN = $idAgen");

    final response = await http.get(
      Uri.parse(
        "http://192.168.1.15/appfreashfish/freashfish_api/get_pesanan_masuk_agen.php?id_agen=$idAgen",
      ),
    );

    print(response.body);

    final hasil =
        jsonDecode(response.body);

    setState(() {

      pesanan =
          hasil["data"] ?? [];

      isLoading = false;

    });

  }

  @override
  void initState() {

    super.initState();

    getPesanan();

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xfff5f7fb),

      appBar: AppBar(

        elevation: 0,

        backgroundColor: Colors.white,

        centerTitle: true,

        title: Text(

          "Pesanan Masuk",

          style: GoogleFonts.poppins(

            color: Colors.black87,

            fontWeight: FontWeight.bold,

          ),

        ),

      ),

      body: RefreshIndicator(

        onRefresh: getPesanan,

        child:

        isLoading

            ? const Center(

                child:

                    CircularProgressIndicator(),

              )

            : pesanan.isEmpty

                ? Center(

                    child: Column(

                      mainAxisAlignment:

                          MainAxisAlignment.center,

                      children: [

                        Icon(

                          Icons.shopping_bag_outlined,

                          size: 90,

                          color: Colors.grey.shade400,

                        ),

                        const SizedBox(height: 20),

                        Text(

                          "Belum ada pesanan",

                          style:

                              GoogleFonts.poppins(

                            fontSize: 18,

                            fontWeight:

                                FontWeight.bold,

                          ),

                        ),

                        Text(

                          "Pesanan dari pembeli akan muncul disini",

                          style:

                              GoogleFonts.poppins(

                            color: Colors.grey,

                          ),

                        ),

                      ],

                    ),

                  )

                : ListView.builder(

                    padding:

                        const EdgeInsets.all(20),

                    itemCount:

                        pesanan.length,

                    itemBuilder:

                        (context, index) {

                      final item =
                          pesanan[index];

                      Color warnaStatus;

                      if (item["status"] ==

                          "Menunggu") {

                        warnaStatus =
                            Colors.orange;

                      } else if (item["status"] ==

                          "Diproses") {

                        warnaStatus =
                            Colors.blue;

                      } else {

                        warnaStatus =
                            Colors.green;

                      }

                      return GestureDetector(

                        onTap: () async {

                          final refresh = await Navigator.push(

                            context,

                            MaterialPageRoute(

                              builder: (_) => DetailPesananPage(
                                data: item,
                              ),

                            ),

                          );

                          if (refresh == true) {
                            getPesanan();
                          }

                        },

                        child: Container(

                          margin:

                              const EdgeInsets.only(

                            bottom: 18,

                          ),

                          decoration:

                              BoxDecoration(

                            color: Colors.white,

                            borderRadius:

                                BorderRadius.circular(

                                    22),

                            boxShadow: [

                              BoxShadow(

                                color: Colors.black

                                    .withOpacity(.05),

                                blurRadius: 15,

                                offset:

                                    const Offset(

                                        0, 6),

                              )

                            ],

                          ),

                          child: Padding(

                            padding:

                                const EdgeInsets.all(

                                    16),

                            child: Column(

                              children: [
                                Row(

                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [

                              ClipRRect(

                                borderRadius: BorderRadius.circular(15),

                                child: Image.network(

                                  "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${item["foto_ikan"]}",

                                  width: 95,

                                  height: 95,

                                  fit: BoxFit.cover,

                                  errorBuilder:

                                      (context, error, stackTrace) {

                                    return Container(

                                      width: 95,

                                      height: 95,

                                      color: Colors.grey.shade200,

                                      child: const Icon(

                                        Icons.image,

                                        size: 40,

                                      ),

                                    );

                                  },

                                ),

                              ),

                              const SizedBox(width: 15),

                              Expanded(

                                child: Column(

                                  crossAxisAlignment:

                                      CrossAxisAlignment.start,

                                  children: [

                                    Row(

                                      children: [

                                        Container(

                                          padding:

                                              const EdgeInsets.symmetric(

                                            horizontal: 12,

                                            vertical: 4,

                                          ),

                                          decoration: BoxDecoration(

                                            color:

                                                item["jenis_pesanan"] ==

                                                        "Pre Order"

                                                    ? Colors.orange.shade100

                                                    : Colors.blue.shade100,

                                            borderRadius:

                                                BorderRadius.circular(20),

                                          ),

                                          child: Text(

                                            item["jenis_pesanan"] ??

                                                "ORDER",

                                            style: GoogleFonts.poppins(

                                              fontSize: 11,

                                              fontWeight:

                                                  FontWeight.bold,

                                              color:

                                                  item["jenis_pesanan"] ==

                                                          "Pre Order"

                                                      ? Colors.orange

                                                      : Colors.blue,

                                            ),

                                          ),

                                        ),

                                        const Spacer(),

                                        Container(

                                          padding:

                                              const EdgeInsets.symmetric(

                                            horizontal: 10,

                                            vertical: 4,

                                          ),

                                          decoration: BoxDecoration(

                                            color:

                                                warnaStatus.withOpacity(.15),

                                            borderRadius:

                                                BorderRadius.circular(15),

                                          ),

                                          child: Text(

                                            item["status"],

                                            style: GoogleFonts.poppins(

                                              color: warnaStatus,

                                              fontWeight:

                                                  FontWeight.bold,

                                              fontSize: 11,

                                            ),

                                          ),

                                        ),

                                      ],

                                    ),

                                    const SizedBox(height: 10),

                                    Text(

                                      item["nama_ikan"],

                                      style: GoogleFonts.poppins(

                                        fontSize: 18,

                                        fontWeight: FontWeight.bold,

                                      ),

                                    ),

                                    const SizedBox(height: 4),

                                    Text(

                                      item["nama_lengkap"],

                                      style: GoogleFonts.poppins(

                                        color: Colors.grey,

                                      ),

                                    ),

                                    const SizedBox(height: 10),

                                    Row(

                                      children: [

                                        const Icon(

                                          Icons.scale,

                                          size: 18,

                                          color: Colors.blue,

                                        ),

                                        const SizedBox(width: 5),

                                        Text(

                                          "${item["jumlah_kg"]} Kg",

                                          style: GoogleFonts.poppins(),

                                        ),

                                      ],

                                    ),

                                    const SizedBox(height: 5),

                                    Row(

                                      children: [

                                        const Icon(

                                          Icons.payments,

                                          size: 18,

                                          color: Colors.orange,

                                        ),

                                        const SizedBox(width: 5),

                                        Text(

                                          rupiah.format(
                                            int.tryParse(item["total_harga"].toString()) ?? 0,
                                          ),

                                          style: GoogleFonts.poppins(

                                            color: Colors.orange,

                                            fontWeight: FontWeight.bold,

                                          ),

                                        ),

                                      ],

                                    ),

                                  ],

                                ),

                              ),

                            ],

                          ),

                          const SizedBox(height: 15),

                          Divider(
                            color: Colors.grey.shade300,
                          ),

                          const SizedBox(height: 10),

                          Row(
                            children: [
                              Expanded(

                                child: OutlinedButton.icon(

                                  icon: const Icon(

                                    Icons.visibility,

                                    size: 18,

                                  ),

                                  label: Text(

                                    "Detail",

                                    style: GoogleFonts.poppins(),

                                  ),

                                  style: OutlinedButton.styleFrom(

                                    foregroundColor: Colors.blue,

                                    side: const BorderSide(

                                      color: Colors.blue,

                                    ),

                                    shape: RoundedRectangleBorder(

                                      borderRadius:

                                          BorderRadius.circular(15),

                                    ),

                                  ),

                                  onPressed: () {

                                    Navigator.push(

                                      context,

                                      MaterialPageRoute(

                                        builder: (_) =>

                                            DetailPesananPage(

                                          data: item,

                                        ),

                                      ),

                                    );

                                  },

                                ),

                              ),

                              const SizedBox(width: 10),

                              Expanded(

                                child: ElevatedButton.icon(

                                  icon: const Icon(

                                    Icons.check_circle,

                                    size: 18,

                                  ),

                                  label: Text(

                                    item["status"] == "Menunggu"

                                        ? "Proses"

                                        : item["status"] == "Diproses"

                                            ? "Selesai"

                                            : "Detail",

                                    style: GoogleFonts.poppins(),

                                  ),

                                  style: ElevatedButton.styleFrom(

                                    backgroundColor:

                                        Colors.blue,

                                    foregroundColor:

                                        Colors.white,

                                    shape: RoundedRectangleBorder(

                                      borderRadius:

                                          BorderRadius.circular(15),

                                    ),

                                  ),

                                  onPressed: () async {

                                  String statusBaru = "";

                                  if (item["status"] == "Menunggu") {

                                    statusBaru = "Diproses";

                                  } else if (item["status"] == "Diproses") {

                                    statusBaru = "Selesai";

                                  } else {

                                    return;

                                  }

                                  bool berhasil =
                                      await UpdateStatusService.updateStatus(

                                    item["id_pesanan"].toString(),
                                    statusBaru,

                                  );

                                  if (berhasil) {

                                    ScaffoldMessenger.of(context).showSnackBar(

                                      SnackBar(
                                        content: Text(
                                          "Status berhasil diubah menjadi $statusBaru",
                                        ),
                                      ),

                                    );

                                    Navigator.pop(context, true);

                                  } 

                                },
                                                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
      ),
    );
  }
}