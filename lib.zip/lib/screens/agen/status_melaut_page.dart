import 'package:flutter/material.dart';

class StatusMelautPage
    extends StatefulWidget {

  const StatusMelautPage({super.key});

  @override
  State<StatusMelautPage> createState() =>
      _StatusMelautPageState();
}

class _StatusMelautPageState
    extends State<StatusMelautPage> {

  String status = "melaut";

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Status Melaut"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(

          children: [

            DropdownButton<String>(
              value: status,
              isExpanded: true,

              items: const [

                DropdownMenuItem(
                  value: "melaut",
                  child: Text("Melaut"),
                ),

                DropdownMenuItem(
                  value: "selesai_melaut",
                  child: Text("Selesai Melaut"),
                ),

              ],

              onChanged: (value) {
                setState(() {
                  status = value!;
                });
              },
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,

              child: ElevatedButton(
                onPressed: () {

                },

                child: const Text(
                  "Update Status",
                ),
              ),
            )

          ],
        ),
      ),
    );
  }
}