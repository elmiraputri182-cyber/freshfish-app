import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'edit_ikan_page.dart';
import 'package:intl/intl.dart';

class DataIkanPage extends StatefulWidget {
  const DataIkanPage({super.key});

  @override
  State<DataIkanPage> createState() => _DataIkanPageState();
}

class _DataIkanPageState extends State<DataIkanPage> {

  final rupiah = NumberFormat.currency(
  locale: 'id_ID',
  symbol: 'Rp ',
  decimalDigits: 0,
);
  List dataIkan = [];

  Future<void> getDataIkan() async {
    final response = await http.get(
      Uri.parse(
        "http://192.168.1.15/appfreashfish/freashfish_api/get_data_ikan.php",
      ),
    );

    setState(() {
      dataIkan = jsonDecode(response.body);
    });
  }

  Future<void> hapusIkan(String id) async {
    final response = await http.post(
      Uri.parse(
        "http://192.168.1.15/appfreashfish/freashfish_api/hapus_ikan.php",
      ),

      body: {"id_ikan": id},
    );

    final data = jsonDecode(response.body);

    if (data["success"] == true) {
      getDataIkan();

      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Data berhasil dihapus")));
    }
  }

  void _showEditDialog(dynamic ikan) {
    showDialog(
      context: context,
      builder: (context) {
        return EditIkanPage(ikan: ikan, onSuccess: getDataIkan);
      },
    );
  }

  Widget buildField(TextEditingController controller, String hint) {
    return TextField(
      controller: controller,

      decoration: InputDecoration(
        labelText: hint,

        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    getDataIkan();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FBFF),

      appBar: AppBar(
        title: Text(
          "Data Ikan",

          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),

        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),

      body: dataIkan.isEmpty
          ? Center(
              child: Text("Data ikan kosong", style: GoogleFonts.poppins()),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(20),

              itemCount: dataIkan.length,

              itemBuilder: (context, index) {
                final ikan = dataIkan[index];

                return Container(
                  margin: const EdgeInsets.only(bottom: 20),

                  padding: const EdgeInsets.all(18),

                  decoration: BoxDecoration(
                    color: Colors.white,

                    borderRadius: BorderRadius.circular(22),

                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue.withOpacity(0.08),

                        blurRadius: 15,

                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      if (ikan["foto_ikan"] != null && ikan["foto_ikan"] != "")
                        ClipRRect(
                          borderRadius: BorderRadius.circular(18),

                          child: Image.network(
                            "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${ikan["foto_ikan"]}",

                            height: 180,

                            width: double.infinity,

                            fit: BoxFit.cover,
                          ),
                        ),

                      const SizedBox(height: 15),

                      Text(
                        ikan["nama_ikan"],

                        style: GoogleFonts.poppins(
                          fontSize: 20,

                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 8),

                      Text("Jenis : ${ikan["jenis_ikan"]}"),

                      Text("Jumlah : ${ikan["jumlah"]} KG"),

                      Container(
                          margin: const EdgeInsets.symmetric(vertical: 10),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Text(
                            rupiah.format(
                              int.tryParse(ikan["harga"].toString()) ?? 0,
                            ),
                            style: GoogleFonts.poppins(
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                        ),
                      

                      Text("Status : ${ikan["status_tersedia"]}"),

                      const SizedBox(height: 10),

                      Row(
                        children: [
                          const Icon(
                            Icons.location_on,
                            color: Colors.red,
                            size: 18,
                          ),

                          const SizedBox(width: 5),

                          Expanded(
                            child: Text(
                              "Lat: ${ikan["latitude"]} | Long: ${ikan["longitude"]}",

                              style: GoogleFonts.poppins(
                                fontSize: 12,

                                color: Colors.grey,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 18),

                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orange,
                              ),

                              onPressed: () {
                                _showEditDialog(ikan);
                              },

                              icon: const Icon(Icons.edit, color: Colors.white),

                              label: Text(
                                "EDIT",

                                style: GoogleFonts.poppins(
                                  color: Colors.white,

                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(width: 10),

                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                              ),

                              onPressed: () {
                                hapusIkan(ikan["id_ikan"]);
                              },

                              icon: const Icon(
                                Icons.delete,
                                color: Colors.white,
                              ),

                              label: Text(
                                "HAPUS",

                                style: GoogleFonts.poppins(
                                  color: Colors.white,

                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
