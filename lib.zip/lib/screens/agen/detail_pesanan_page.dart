import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import '../../services/update_status_service.dart';
import 'package:intl/intl.dart';


class DetailPesananPage extends StatelessWidget {
        final rupiah = NumberFormat.currency(
          locale: 'id_ID',
          symbol: 'Rp ',
          decimalDigits: 0,
        );

  final Map data;

  DetailPesananPage({
    super.key,
    required this.data,
  });

  Color getStatusColor(String status) {
      
    switch (status) {

      case "Menunggu":
        return Colors.orange;

      case "Diproses":
        return Colors.blue;

      case "Selesai":
        return Colors.green;

      default:
        return Colors.grey;

    }

  }

  @override
  Widget build(BuildContext context) {

    Color statusColor =
        getStatusColor(data["status"]);

    return Scaffold(

      backgroundColor: const Color(0xfff5f7fb),

      appBar: AppBar(

        elevation: 0,

        backgroundColor: Colors.white,

        foregroundColor: Colors.black,

        title: Text(

          "Detail Pesanan",

          style: GoogleFonts.poppins(

            fontWeight: FontWeight.bold,

          ),

        ),

      ),

      body: SingleChildScrollView(

        padding: const EdgeInsets.all(20),

        child: Column(

          children: [

            Container(

              decoration: BoxDecoration(

                color: Colors.white,

                borderRadius:
                    BorderRadius.circular(25),

                boxShadow: [

                  BoxShadow(

                    color: Colors.black.withOpacity(.05),

                    blurRadius: 12,

                  )

                ],

              ),

              child: Column(

                children: [

                  ClipRRect(

                    borderRadius:

                        const BorderRadius.only(

                      topLeft: Radius.circular(25),

                      topRight: Radius.circular(25),

                    ),

                    child: Image.network(

                      "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${data["foto_ikan"] ?? ""}",

                      errorBuilder: (context, error, stackTrace) {

                        return Container(
                          
                          height: 220,
                          color: Colors.grey.shade200,
                          child: const Icon(
                            Icons.image,
                            size: 60,
                          ),
                        );
                      },
                    )

                  ),

                  Padding(

                    padding: const EdgeInsets.all(20),

                    child: Column(

                      crossAxisAlignment:
                          CrossAxisAlignment.start,

                      children: [

                        Row(

                          children: [

                            Container(

                              padding:

                                  const EdgeInsets.symmetric(

                                horizontal: 15,

                                vertical: 6,

                              ),

                              decoration: BoxDecoration(

                                color: statusColor.withOpacity(.15),

                                borderRadius:
                                    BorderRadius.circular(20),

                              ),

                              child: Text(

                                data["status"],

                                style: GoogleFonts.poppins(

                                  color: statusColor,

                                  fontWeight:
                                      FontWeight.bold,

                                ),

                              ),

                            ),

                            const Spacer(),

                            Container(

                              padding:

                                  const EdgeInsets.symmetric(

                                horizontal: 12,

                                vertical: 6,

                              ),

                              decoration: BoxDecoration(

                                color:

                                    data["jenis_pesanan"] ==

                                            "Pre Order"

                                        ? Colors.orange.shade100

                                        : Colors.blue.shade100,

                                borderRadius:
                                    BorderRadius.circular(20),

                              ),

                              child: Text(

                                data["jenis_pesanan"],

                                style: GoogleFonts.poppins(

                                  fontWeight:
                                      FontWeight.bold,

                                  color:

                                      data["jenis_pesanan"] ==

                                              "Pre Order"

                                          ? Colors.orange

                                          : Colors.blue,

                                ),

                              ),

                            ),

                          ],

                        ),

                        const SizedBox(height: 20),

                        Text(

                          data["nama_ikan"],

                          style: GoogleFonts.poppins(

                            fontSize: 24,

                            fontWeight:
                                FontWeight.bold,

                          ),

                        ),

                        const SizedBox(height: 15),

                        detailItem(
                          Icons.person,
                          "Pembeli",
                          data["nama_lengkap"] ?? "-",
                        ),

                        detailItem(
                          Icons.phone,
                          "No HP",
                          data["no_telp"] ?? "-",
                        ),

                        detailItem(

                          Icons.payments,

                          "Total",

                          Text(
                          rupiah.format(
                            int.tryParse(data["total_harga"].toString()) ?? 0,
                          ),
                        ),

                        ),

                        detailItem(

                          Icons.payment,

                          "Pembayaran",

                          data["metode_pembayaran"] ?? "-",

                        ),

                        detailItem(

                          Icons.local_shipping,

                          "Pengambilan",

                          data["metode_pengambilan"] ?? "-",

                        ),

                        if(data["jenis_pesanan"]=="Pre Order")

                        detailItem(

                          Icons.calendar_month,

                          "Tanggal Dibutuhkan",

                          data["tanggal_dibutuhkan"] ?? "-",

                        ),

                        if(data["catatan"]!=null)

                        detailItem(

                          Icons.note,

                          "Catatan",

                          data["catatan"] ?? "-",

                        ),

                      ],

                    ),

                  ),

                ],

              ),

            ),

            const SizedBox(height: 25),

            SizedBox(

              width: double.infinity,

              height: 55,

              child: ElevatedButton(

                style: ElevatedButton.styleFrom(

                  backgroundColor: Colors.blue,

                  shape: RoundedRectangleBorder(

                    borderRadius:
                        BorderRadius.circular(15),

                  ),

                ),

                onPressed: () async {

                      String statusBaru = "";

                      if(data["status"]=="Menunggu"){

                        statusBaru="Diproses";

                      }else if(data["status"]=="Diproses"){

                        statusBaru="Selesai";

                      }else{

                        return;

                      }

                      bool berhasil =
                      await UpdateStatusService.updateStatus(

                        data["id_pesanan"].toString(),
                        statusBaru,

                      );

                      if (berhasil) {

                    if (!context.mounted) return;

                    Navigator.pop(context, true);

                  }

                },

                child: Text(

                  data["status"]=="Menunggu"

                      ? "PROSES PESANAN"

                      : data["status"]=="Diproses"

                          ? "SELESAIKAN"

                          : "PESANAN SELESAI",

                  style: GoogleFonts.poppins(

                    color: Colors.white,

                    fontWeight:
                        FontWeight.bold,

                  ),

                ),

              ),

            ),

          ],

        ),

      ),

    );

  }

  Widget detailItem(

    IconData icon,

    String title,

    dynamic value) {

    return Padding(

      padding: const EdgeInsets.only(bottom: 15),

      child: Row(

        children: [

          CircleAvatar(

            radius: 20,

            backgroundColor:
                Colors.blue.shade50,

            child: Icon(

              icon,

              color: Colors.blue,

            ),

          ),

          const SizedBox(width: 15),

          Expanded(

            child: Column(

              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [

                Text(

                  title,

                  style: GoogleFonts.poppins(

                    color: Colors.grey,

                    fontSize: 12,

                  ),

                ),

                Text(

                  value?.toString() ?? "-",

                  style: GoogleFonts.poppins(

                    fontWeight:
                        FontWeight.bold,

                    fontSize: 15,

                  ),

                ),

              ],

            ),

          ),

        ],

      ),

    );

  }

}