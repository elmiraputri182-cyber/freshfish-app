import 'dart:convert';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../services/statistik_service.dart';
import 'package:intl/intl.dart';

class StatistikAgenPage extends StatefulWidget {
  const StatistikAgenPage({super.key});

  @override
  State<StatistikAgenPage> createState() =>
      _StatistikAgenPageState();
}

class _StatistikAgenPageState
    extends State<StatistikAgenPage> {
      final rupiah = NumberFormat.currency(
        locale: 'id_ID',
        symbol: 'Rp ',
        decimalDigits: 0,
      );

  bool isLoading = true;

  int totalPesanan = 0;
  int totalNelayan = 0;
  int totalStok = 0;
  int totalJenisIkan = 0;
  int totalPemasukan = 0;

  int pesananMenunggu = 0;
  int pesananDiproses = 0;
  int pesananSelesai = 0;

  List grafikPemasukan = [];

  @override
  void initState() {
    super.initState();
    loadStatistik();
  }

  Future<void> loadStatistik() async {

    try {

      final pref =
          await SharedPreferences.getInstance();

      final idUser =
          pref.getString("id_user") ?? "";

      //-----------------------------
      // PESANAN
      //-----------------------------

      final pesananResponse =
          await http.get(

        Uri.parse(

          "http://192.168.1.15/appfreashfish/freashfish_api/get_pemesanan_agen.php?id_user=$idUser",

        ),

      );

      if (pesananResponse.statusCode == 200) {

        final pesanan =
            jsonDecode(
              pesananResponse.body,
            );

        if (pesanan["success"] == true) {

          List list =
              pesanan["data"];

          totalPesanan =
              list.length;

          pesananSelesai =
              list.where(

                (e) =>
                    e["status"]
                        .toString()
                        .toLowerCase() ==
                    "selesai",

              ).length;

          pesananDiproses =
              list.where(

                (e) =>
                    e["status"]
                        .toString()
                        .toLowerCase() ==
                    "diproses",

              ).length;

          pesananMenunggu =
              list.where(

                (e) =>
                    e["status"]
                        .toString()
                        .toLowerCase() ==
                    "menunggu",

              ).length;
        }
      }

      //-----------------------------
      // STATISTIK
      //-----------------------------

      final statistikResponse =
          await http.get(

        Uri.parse(

          "http://192.168.1.15/appfreashfish/freashfish_api/get_statistik_agen.php?id_user=$idUser",

        ),

      );

      if (statistikResponse.statusCode == 200) {

        final statistik =
            jsonDecode(
              statistikResponse.body,
            );

        if (statistik["success"] == true) {

          totalStok = int.tryParse(

                statistik["total_stok"]
                    .toString(),

              ) ??
              0;

          totalJenisIkan =
              int.tryParse(

                    statistik["total_jenis"]
                        .toString(),

                  ) ??
                  0;

          totalPemasukan =
              int.tryParse(

                    statistik["total_pemasukan"]
                        .toString(),

                  ) ??
                  0;
        }
      }

      //-----------------------------
      // GRAFIK
      //-----------------------------

      final grafikResponse =
          await http.get(

        Uri.parse(

          "http://192.168.1.15/appfreashfish/freashfish_api/get_grafik_pemasukan.php?id_user=$idUser",

        ),

      );

      if (grafikResponse.statusCode == 200) {

        final grafik =
            jsonDecode(
              grafikResponse.body,
            );

        if (grafik["success"] == true) {

          grafikPemasukan =
              grafik["data"] ?? [];
        }
      }

      totalNelayan = 8;

      setState(() {

        isLoading = false;

      });

    } catch (e) {

      debugPrint(e.toString());

      setState(() {

        isLoading = false;

      });

    }

  }

  @override
  Widget build(BuildContext context) {

    if (isLoading) {

      return const Scaffold(

        body: Center(

          child:
              CircularProgressIndicator(),

        ),

      );

    }

    return Scaffold(

      backgroundColor:
          const Color(0xffF5F7FA),

      appBar: AppBar(

        elevation: 0,

        backgroundColor: Colors.white,

        centerTitle: true,

        title: Text(

          "Statistik Penjualan",

          style:
              GoogleFonts.poppins(

            color: Colors.black,

            fontWeight:
                FontWeight.bold,

          ),

        ),

      ),

      body: RefreshIndicator(

        onRefresh: loadStatistik,

        child: SingleChildScrollView(

          physics:
              const AlwaysScrollableScrollPhysics(),

          padding:
              const EdgeInsets.all(16),

          child: Column(

            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [

              Text(

                "Ringkasan Penjualan",

                style:
                    GoogleFonts.poppins(

                  fontSize: 18,

                  fontWeight:
                      FontWeight.bold,

                ),

              ),

              const SizedBox(
                height: 16,
              ),
                            Row(

                children: [

                  Expanded(

                    child: buildStatisticCard(

                      title: "Total Pesanan",

                      value: "$totalPesanan",

                      icon: Icons.shopping_bag,

                      color: Colors.blue,

                    ),

                  ),

                  const SizedBox(width: 12),

                  Expanded(

                    child: buildStatisticCard(

                      title: "Total Pemasukan",

                      value: "Rp$totalPemasukan",

                      icon: Icons.payments,

                      color: Colors.green,

                    ),

                  ),

                ],

              ),

              const SizedBox(height: 12),

              Row(

                children: [

                  Expanded(

                    child: buildStatisticCard(

                      title: "Stok Ikan",

                      value: "$totalStok",

                      icon: Icons.set_meal,

                      color: Colors.orange,

                    ),

                  ),

                  const SizedBox(width: 12),

                  Expanded(

                    child: buildStatisticCard(

                      title: "Jenis Ikan",

                      value: "$totalJenisIkan",

                      icon: Icons.category,

                      color: Colors.purple,

                    ),

                  ),

                ],

              ),

              const SizedBox(height: 25),

              Text(

                "Grafik Pemasukan",

                style: GoogleFonts.poppins(

                  fontWeight: FontWeight.bold,

                  fontSize: 18,

                ),

              ),

              const SizedBox(height: 15),

              Container(

                padding: const EdgeInsets.all(20),

                decoration: BoxDecoration(

                  color: Colors.white,

                  borderRadius:

                      BorderRadius.circular(20),

                  boxShadow: [

                    BoxShadow(

                      color: Colors.grey.shade200,

                      blurRadius: 10,

                    ),

                  ],

                ),

                child: buildGrafikPemasukan(),

              ),

              const SizedBox(height: 25),

              Text(

                "Aktivitas Pesanan",

                style: GoogleFonts.poppins(

                  fontWeight: FontWeight.bold,

                  fontSize: 18,

                ),

              ),

              const SizedBox(height: 15),

              Container(

                padding: const EdgeInsets.all(20),

                decoration: BoxDecoration(

                  color: Colors.white,

                  borderRadius:

                      BorderRadius.circular(20),

                  boxShadow: [

                    BoxShadow(

                      color: Colors.grey.shade200,

                      blurRadius: 10,

                    ),

                  ],

                ),

                child: Column(

                  children: [

                    buildDetailRow(

                      "Pesanan Menunggu",

                      "$pesananMenunggu",

                      Colors.orange,

                    ),

                    const SizedBox(height: 12),

                    buildDetailRow(

                      "Pesanan Diproses",

                      "$pesananDiproses",

                      Colors.blue,

                    ),

                    const SizedBox(height: 12),

                    buildDetailRow(

                      "Pesanan Selesai",

                      "$pesananSelesai",

                      Colors.green,

                    ),

                  ],

                ),

              ),

              const SizedBox(height: 25),

              Text(

                "Progress Penyelesaian",

                style: GoogleFonts.poppins(

                  fontWeight: FontWeight.bold,

                  fontSize: 18,

                ),

              ),

              const SizedBox(height: 15),

              Container(

                padding: const EdgeInsets.all(20),

                decoration: BoxDecoration(

                  color: Colors.white,

                  borderRadius:

                      BorderRadius.circular(20),

                  boxShadow: [

                    BoxShadow(

                      color: Colors.grey.shade200,

                      blurRadius: 10,

                    ),

                  ],

                ),

                child: Column(

                  children: [

                    Row(

                      mainAxisAlignment:

                          MainAxisAlignment.spaceBetween,

                      children: [

                        Column(

                          crossAxisAlignment:

                              CrossAxisAlignment.start,

                          children: [

                            Text(

                              "Tingkat Penyelesaian",

                              style:

                                  GoogleFonts.poppins(

                                fontWeight:

                                    FontWeight.bold,

                              ),

                            ),

                            const SizedBox(height: 8),

                            Text(

                              "${((pesananSelesai / (totalPesanan == 0 ? 1 : totalPesanan)) * 100).toStringAsFixed(1)}%",

                              style:

                                  GoogleFonts.poppins(

                                fontSize: 28,

                                color: Colors.green,

                                fontWeight:

                                    FontWeight.bold,

                              ),

                            ),

                          ],

                        ),

                        SizedBox(

                          width: 90,

                          height: 90,

                          child:

                              CircularProgressIndicator(

                            strokeWidth: 8,

                            value: totalPesanan == 0

                                ? 0

                                : pesananSelesai /

                                    totalPesanan,

                          ),

                        ),

                      ],

                    ),

                  ],

                ),

              ),

              const SizedBox(height: 25),

              Text(

                "Ringkasan Keuangan",

                style: GoogleFonts.poppins(

                  fontWeight: FontWeight.bold,

                  fontSize: 18,

                ),

              ),

              const SizedBox(height: 15),

              Container(

                padding: const EdgeInsets.all(20),

                decoration: BoxDecoration(

                  color: Colors.white,

                  borderRadius:

                      BorderRadius.circular(20),

                  boxShadow: [

                    BoxShadow(

                      color: Colors.grey.shade200,

                      blurRadius: 10,

                    ),

                  ],

                ),

                child: Column(

                  children: [

                    buildDetailRow(

                      "Total Pemasukan",

                      "Rp$totalPemasukan",

                      Colors.green,

                    ),

                    const SizedBox(height: 12),

                    buildDetailRow(

                      "Rata-rata Transaksi",

                      rupiah.format(
                        totalPesanan == 0
                            ? 0
                            : (totalPemasukan ~/ totalPesanan),
                      ),

                      Colors.blue,

                    ),

                    const SizedBox(height: 12),

                    buildDetailRow(

                      "Total Nelayan",

                      "$totalNelayan",

                      Colors.purple,

                    ),

                  ],

                ),

              ),

              const SizedBox(height: 30),
                          ],
          ),
        ),
      ),
    );
  }

  Widget buildStatisticCard({

    required String title,

    required String value,

    required IconData icon,

    required Color color,

  }) {

    return Container(

      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(

        color: Colors.white,

        borderRadius: BorderRadius.circular(20),

        boxShadow: [

          BoxShadow(

            color: Colors.grey.shade200,

            blurRadius: 10,

            offset: const Offset(0, 5),

          ),

        ],

      ),

      child: Column(

        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [

          Container(

            padding: const EdgeInsets.all(10),

            decoration: BoxDecoration(

              color: color.withOpacity(.1),

              borderRadius:
                  BorderRadius.circular(12),

            ),

            child: Icon(

              icon,

              color: color,

              size: 28,

            ),

          ),

          const SizedBox(height: 15),

          Text(

            title,

            style: GoogleFonts.poppins(

              color: Colors.grey,

              fontSize: 13,

            ),

          ),

          const SizedBox(height: 8),

          Text(

            value,

            style: GoogleFonts.poppins(

              fontWeight: FontWeight.bold,

              fontSize: 22,

              color: color,

            ),

          ),

        ],

      ),

    );

  }

  Widget buildDetailRow(

    String title,

    String value,

    Color color,

  ) {

    return Row(

      mainAxisAlignment:
          MainAxisAlignment.spaceBetween,

      children: [

        Text(

          title,

          style: GoogleFonts.poppins(

            fontSize: 14,

            color: Colors.black87,

          ),

        ),

        Container(

          padding:
              const EdgeInsets.symmetric(

            horizontal: 12,

            vertical: 6,

          ),

          decoration: BoxDecoration(

            color: color.withOpacity(.12),

            borderRadius:
                BorderRadius.circular(30),

          ),

          child: Text(

            value,

            style: GoogleFonts.poppins(

              color: color,

              fontWeight:
                  FontWeight.bold,

            ),

          ),

        ),

      ],

    );

  }

  Widget buildGrafikPemasukan() {

    if (grafikPemasukan.isEmpty) {

      return SizedBox(

        height: 250,

        child: Center(

          child: Text(

            "Belum ada data pemasukan",

            style: GoogleFonts.poppins(),

          ),

        ),

      );

    }

    return SizedBox(

      height: 260,

      child: LineChart(

        LineChartData(

          gridData: FlGridData(

            show: true,

          ),

          borderData: FlBorderData(

            show: false,

          ),

          titlesData: FlTitlesData(

            topTitles: AxisTitles(

              sideTitles:

                  SideTitles(

                showTitles: false,

              ),

            ),

            rightTitles: AxisTitles(

              sideTitles:

                  SideTitles(

                showTitles: false,

              ),

            ),

            leftTitles: AxisTitles(

              sideTitles:

                  SideTitles(

                showTitles: true,

                reservedSize: 40,

              ),

            ),

            bottomTitles: AxisTitles(

              sideTitles:

                  SideTitles(

                showTitles: true,

                getTitlesWidget:

                    (value, meta) {

                  int index =
                      value.toInt();

                  if (index >=
                      grafikPemasukan
                          .length) {

                    return const SizedBox();

                  }

                  return Padding(

                    padding:
                        const EdgeInsets.only(

                      top: 8,

                    ),

                    child: Text(

                      grafikPemasukan[index]
                          ["bulan"],

                      style:
                          GoogleFonts.poppins(

                        fontSize: 11,

                      ),

                    ),

                  );

                },

              ),

            ),

          ),

          lineBarsData: [

            LineChartBarData(

              isCurved: true,

              barWidth: 4,

              dotData: FlDotData(

                show: true,

              ),

              belowBarData:

                  BarAreaData(

                show: true,

                color: Colors.blue
                    .withOpacity(.15),

              ),

              spots: List.generate(

                grafikPemasukan.length,

                (index) {

                  return FlSpot(

                    index.toDouble(),

                    double.parse(

                      grafikPemasukan[index]
                              ["pemasukan"]
                          .toString(),

                    ),

                  );

                },

              ),

            ),

          ],

        ),

      ),

    );

  }

}