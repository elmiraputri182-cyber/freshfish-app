import 'package:flutter/material.dart';

import 'home_agen_page.dart';
import 'statistik_agen_page.dart';
import 'akun_agen_page.dart';
import 'laporan_agen_page.dart';
import 'pesanan_masuk_page.dart';

class DashboardAgen extends StatefulWidget {
  const DashboardAgen({super.key});

  @override
  State<DashboardAgen> createState() =>
      _DashboardAgenState();
}

class _DashboardAgenState
    extends State<DashboardAgen> {

  int selectedIndex = 0;

  final List pages = [

    const HomeAgenPage(),

    const PesananMasukPage(),

    const StatistikAgenPage(),

    const LaporanAgenPage(),

    const AkunAgenPage(),
  ];

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      body: pages[selectedIndex],

      bottomNavigationBar:
          BottomNavigationBar(

        currentIndex: selectedIndex,

        selectedItemColor: Colors.blue,

        unselectedItemColor:
            Colors.grey,

        onTap: (index){

          setState(() {

            selectedIndex = index;
          });
        },

        items: const [

          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Beranda",
          ),

          BottomNavigationBarItem(
            icon:
                Icon(Icons.shopping_basket),
            label: "Pesanan",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: "Statistik",
          ),
          
          BottomNavigationBarItem(
            icon: Icon(Icons.description),
            label: "Laporan",
          ),


          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Akun",
          ),
        ],
      ),
    );
  }
}