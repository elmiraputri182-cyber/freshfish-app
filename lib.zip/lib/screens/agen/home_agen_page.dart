import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'data_ikan_page.dart';
import 'tambah_ikan_page.dart';

class HomeAgenPage extends StatefulWidget {
  const HomeAgenPage({super.key});

  @override
  State<HomeAgenPage> createState() => _HomeAgenPageState();
}

class _HomeAgenPageState extends State<HomeAgenPage> {
  int totalStok = 0;
  int totalPesanan = 0;
  int totalNelayan = 8;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadDashboardData();
  }

  Future<void> loadDashboardData() async {
    try {
      final pref = await SharedPreferences.getInstance();
      final idUser = pref.getString("id_user") ?? "";

      // Ambil data ikan (stok)
      final ikanResponse = await http.get(
        Uri.parse(
          "http://192.168.1.15/appfreashfish/freashfish_api/get_data_ikan.php?id_user=$idUser",
        ),
      );

      if (ikanResponse.statusCode == 200) {
        final ikanData = jsonDecode(ikanResponse.body);
        if (ikanData["success"] == true) {
          final ikanList = ikanData["data"] as List;
          int stok = 0;
          for (var ikan in ikanList) {
            stok += int.tryParse(ikan["jumlah"].toString()) ?? 0;
          }
          setState(() {
            totalStok = stok;
          });
        }
      }

      // Ambil data pesanan
      final pesananResponse = await http.get(
        Uri.parse(
          "http://192.168.1.15/appfreashfish/freashfish_api/get_pemesanan_agen.php?id_user=$idUser",
        ),
      );

      if (pesananResponse.statusCode == 200) {
        final pesananData = jsonDecode(pesananResponse.body);
        if (pesananData["success"] == true) {
          final pesananList = pesananData["data"] as List;
          setState(() {
            totalPesanan = pesananList.length;
          });
        }
      }

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      print("Error: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FBFF),

      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: loadDashboardData,
              child: SafeArea(
                child: Stack(
                  children: [
                    Positioned(
                      top: -100,
                      right: -80,
                      child: Container(
                        height: 250,
                        width: 250,
                        decoration: BoxDecoration(
                          color: Colors.blue.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),

                    Positioned(
                      bottom: -120,
                      left: -90,
                      child: Container(
                        height: 280,
                        width: 280,
                        decoration: BoxDecoration(
                          color: Colors.lightBlue.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),

                    SingleChildScrollView(
                      padding: const EdgeInsets.all(22),

                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [
                          const SizedBox(height: 10),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,

                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,

                                children: [
                                  Text(
                                    "Halo, Agen 👋",

                                    style: GoogleFonts.poppins(
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold,

                                      color: const Color(0xFF1565C0),
                                    ),
                                  ),

                                  const SizedBox(height: 4),

                                  Text(
                                    "Wilayah Pulau Bengkalis",

                                    style: GoogleFonts.poppins(
                                      fontSize: 13,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),

                              Container(
                                padding: const EdgeInsets.all(14),

                                decoration: BoxDecoration(
                                  color: Colors.white,

                                  borderRadius: BorderRadius.circular(18),

                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.blue.withOpacity(0.08),
                                      blurRadius: 15,
                                      offset: const Offset(0, 8),
                                    ),
                                  ],
                                ),

                                child: const Icon(Icons.person, color: Colors.blue),
                              ),
                            ],
                          ),

                          const SizedBox(height: 30),

                          Container(
                            padding: const EdgeInsets.all(20),

                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFF2196F3), Color(0xFF42A5F5)],
                              ),

                              borderRadius: BorderRadius.circular(28),

                              boxShadow: [
                                BoxShadow(
                                  color: Colors.blue.withOpacity(0.25),
                                  blurRadius: 20,
                                  offset: const Offset(0, 10),
                                ),
                              ],
                            ),

                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(16),

                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),

                                    borderRadius: BorderRadius.circular(18),
                                  ),

                                  child: const Icon(
                                    Icons.sailing,
                                    color: Colors.white,
                                    size: 35,
                                  ),
                                ),

                                const SizedBox(width: 18),

                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,

                                    children: [
                                      Text(
                                        "Nelayan Sedang Melaut",

                                        style: GoogleFonts.poppins(
                                          fontSize: 16,

                                          fontWeight: FontWeight.bold,

                                          color: Colors.white,
                                        ),
                                      ),

                                      const SizedBox(height: 5),

                                      Text(
                                        "Ikan segar tersedia dalam 2 hari lagi",

                                        style: GoogleFonts.poppins(
                                          fontSize: 12,

                                          color: Colors.white.withOpacity(0.9),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 28),

                          Row(
                            children: [
                              buildStatCard(
                                totalStok.toString(),
                                "Stok",
                                Icons.set_meal,
                              ),

                              const SizedBox(width: 14),

                              buildStatCard(
                                totalPesanan.toString(),
                                "Pesanan",
                                Icons.shopping_bag,
                              ),

                              const SizedBox(width: 14),

                              buildStatCard(
                                totalNelayan.toString(),
                                "Nelayan",
                                Icons.groups,
                              ),
                            ],
                          ),

                          const SizedBox(height: 32),

                          Text(
                            "Menu Utama",

                            style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 18),

                          Row(
                            children: [
                              Expanded(
                                child: buildMenuCard(
                                  context,

                                  Icons.inventory_2,

                                  "Kelola\nData Ikan",

                                  "data_ikan",
                                ),
                              ),

                              const SizedBox(width: 18),

                              Expanded(
                                child: buildMenuCard(
                                  context,

                                  Icons.add_circle,

                                  "Tambah\nIkan",

                                  "tambah_ikan",
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget buildStatCard(String angka, String title, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18),

        decoration: BoxDecoration(
          color: Colors.white,

          borderRadius: BorderRadius.circular(22),

          boxShadow: [
            BoxShadow(
              color: Colors.blue.withOpacity(0.08),
              blurRadius: 15,
              offset: const Offset(0, 8),
            ),
          ],
        ),

        child: Column(
          children: [
            Icon(icon, color: Colors.blue),

            const SizedBox(height: 10),

            Text(
              angka,

              style: GoogleFonts.poppins(
                fontSize: 22,
                fontWeight: FontWeight.bold,

                color: const Color(0xFF1565C0),
              ),
            ),

            Text(
              title,

              style: GoogleFonts.poppins(color: Colors.grey, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildMenuCard(
    BuildContext context,
    IconData icon,
    String title,
    String pageType,
  ) {
    return GestureDetector(
      onTap: () {
        Widget page;
        if (pageType == "tambah_ikan") {
          page = TambahIkanPage(
            onSuccess: () {
              // Refresh atau update UI jika diperlukan
            },
          );
        } else {
          page = const DataIkanPage();
        }

        Navigator.push(context, MaterialPageRoute(builder: (_) => page));
      },

      child: Container(
        height: 180,

        decoration: BoxDecoration(
          color: Colors.white,

          borderRadius: BorderRadius.circular(28),

          boxShadow: [
            BoxShadow(
              color: Colors.blue.withOpacity(0.08),
              blurRadius: 15,
              offset: const Offset(0, 8),
            ),
          ],
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            Container(
              padding: const EdgeInsets.all(18),

              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),

                shape: BoxShape.circle,
              ),

              child: Icon(icon, color: Colors.blue, size: 35),
            ),

            const SizedBox(height: 18),

            Text(
              title,

              textAlign: TextAlign.center,

              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w600,

                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
