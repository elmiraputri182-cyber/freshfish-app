import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

class DataPesananPage extends StatefulWidget {
  const DataPesananPage({super.key});

  @override
  State<DataPesananPage> createState() =>
      _DataPesananPageState();
}

class _DataPesananPageState
    extends State<DataPesananPage> {

  List pesanan = [];

  Future<void> getPesanan() async {

    try {

      final response = await http.get(

        Uri.parse(
          "http://192.168.1.31/appfreashfish/freashfish_api/get_pesanan_admin.php",
        ),
      );

      setState(() {

        pesanan =
            jsonDecode(response.body);

      });

    } catch (e) {

      print("ERROR PESANAN = $e");

    }
  }

  @override
  void initState() {
    super.initState();
    getPesanan();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xffF5F8FF),

      appBar: AppBar(

        title: Text(

          "Data Pesanan",

          style:
              GoogleFonts.poppins(
            fontWeight:
                FontWeight.bold,
          ),
        ),

        backgroundColor:
            Colors.blue,

        foregroundColor:
            Colors.white,
      ),

      body: pesanan.isEmpty

          ? const Center(
              child:
                  CircularProgressIndicator(),
            )

          : ListView.builder(

              padding:
                  const EdgeInsets.all(20),

              itemCount:
                  pesanan.length,

              itemBuilder:
                  (context,index){

                final item =
                    pesanan[index];

                return Container(

                  margin:
                      const EdgeInsets.only(
                    bottom: 15,
                  ),

                  padding:
                      const EdgeInsets.all(
                    18,
                  ),

                  decoration:
                      BoxDecoration(

                    color:
                        Colors.white,

                    borderRadius:
                        BorderRadius
                            .circular(
                      20,
                    ),

                    boxShadow: [

                      BoxShadow(

                        color: Colors
                            .black
                            .withOpacity(
                          0.05,
                        ),

                        blurRadius:
                            10,
                      ),
                    ],
                  ),

                  child: Column(

                    crossAxisAlignment:
                        CrossAxisAlignment
                            .start,

                    children: [

                      Text(

                        item["nama_ikan"] ??
                            "-",

                        style:
                            GoogleFonts
                                .poppins(

                          fontSize: 18,

                          fontWeight:
                              FontWeight
                                  .bold,
                        ),
                      ),

                      const SizedBox(
                          height: 8),

                      Text(
                        "Pembeli : ${item["nama_lengkap"]}",
                      ),

                      Text(
                        "Jumlah : ${item["jumlah_kg"]} Kg",
                      ),

                      Text(
                        "Pembayaran : ${item["metode_pembayaran"]}",
                      ),

                      Text(
                        "Total : Rp ${item["total_harga"]}",
                      ),

                      const SizedBox(
                          height: 10),

                      Container(

                        padding:
                            const EdgeInsets
                                .symmetric(
                          horizontal:
                              12,
                          vertical: 6,
                        ),

                        decoration:
                            BoxDecoration(

                          color: Colors
                              .green
                              .withOpacity(
                            0.1,
                          ),

                          borderRadius:
                              BorderRadius
                                  .circular(
                            15,
                          ),
                        ),

                        child: Text(

                          "Pesanan Masuk",

                          style:
                              GoogleFonts
                                  .poppins(

                            color: Colors
                                .green,

                            fontWeight:
                                FontWeight
                                    .bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}