import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

class DataUserPage extends StatefulWidget {
  const DataUserPage({super.key});

  @override
  State<DataUserPage> createState() => _DataUserPageState();
}

class _DataUserPageState extends State<DataUserPage> {
  List users = [];

  Future<void> getUsers() async {
    try {
      final response = await http.get(
        Uri.parse(
          "http://192.168.1.15/appfreashfish/freashfish_api/get_users.php",
        ),
      );

      setState(() {
        users = jsonDecode(response.body);
      });
    } catch (e) {
      print("ERROR USER = $e");
    }
  }

  Future<void> hapusUser(String idUser) async {
    try {
      final response = await http.post(
        Uri.parse(
          "http://192.168.1.15/appfreashfish/freashfish_api/hapus_user.php",
        ),
        body: {
          "id_user": idUser,
        },
      );

      final data = jsonDecode(response.body);

      if (data["success"] == true) {
        getUsers();

        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("User berhasil dihapus"),
          ),
        );
      }
    } catch (e) {
      print("ERROR HAPUS USER = $e");
    }
  }

  @override
  void initState() {
    super.initState();
    getUsers();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F8FF),

      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,

        title: Text(
          "Data User",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: users.isEmpty
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(20),

              itemCount: users.length,

              itemBuilder: (context, index) {
                final user = users[index];

                return Container(
                  margin: const EdgeInsets.only(bottom: 15),

                  decoration: BoxDecoration(
                    color: Colors.white,

                    borderRadius:
                        BorderRadius.circular(20),

                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                      ),
                    ],
                  ),

                  child: ListTile(
                    contentPadding:
                        const EdgeInsets.all(15),

                    leading: CircleAvatar(
                      backgroundColor:
                          Colors.blue.withOpacity(0.1),

                      child: const Icon(
                        Icons.person,
                        color: Colors.blue,
                      ),
                    ),

                    title: Text(
                      user["nama_lengkap"] ?? "-",
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    subtitle: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,

                      children: [
                        const SizedBox(height: 5),

                        Text(
                          "Username : ${user["username"]}",
                        ),

                        Text(
                          "Role : ${user["role"]}",
                        ),

                        Text(
                          "No Telp : ${user["no_telp"]}",
                        ),

                        Text(
                          "Alamat : ${user["alamat"]}",
                        ),
                      ],
                    ),

                    trailing: IconButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (_) {
                            return AlertDialog(
                              title:
                                  const Text("Konfirmasi"),

                              content: const Text(
                                "Yakin ingin menghapus user ini?",
                              ),

                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(
                                        context);
                                  },
                                  child:
                                      const Text("Batal"),
                                ),

                                ElevatedButton(
                                  style:
                                      ElevatedButton
                                          .styleFrom(
                                    backgroundColor:
                                        Colors.red,
                                  ),

                                  onPressed: () {
                                    Navigator.pop(
                                        context);

                                    hapusUser(
                                      user["id_user"]
                                          .toString(),
                                    );
                                  },

                                  child: const Text(
                                    "Hapus",
                                    style: TextStyle(
                                      color:
                                          Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      },

                      icon: const Icon(
                        Icons.delete,
                        color: Colors.red,
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}