import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class DataIkanAdminPage extends StatefulWidget {
  const DataIkanAdminPage({super.key});

  @override
  State<DataIkanAdminPage> createState() =>
      _DataIkanAdminPageState();
}

class _DataIkanAdminPageState
    extends State<DataIkanAdminPage> {
      
    final rupiah = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  List dataIkan = [];

  Future<void> getDataIkan() async {

    final response = await http.get(

      Uri.parse(
        "http://192.168.1.15/appfreashfish/freashfish_api/get_data_ikan_admin.php",
      ),
    );

    setState(() {

      dataIkan =
          jsonDecode(response.body);

    });
  }

  @override
  void initState() {
    super.initState();
    getDataIkan();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text(
          "Data Ikan",
        ),

        backgroundColor:
            Colors.blue,

        foregroundColor:
            Colors.white,
      ),

      body: ListView.builder(

        padding:
            const EdgeInsets.all(15),

        itemCount:
            dataIkan.length,

        itemBuilder:
            (context,index){

          final ikan =
              dataIkan[index];

          return Card(

            margin:
                const EdgeInsets.only(
              bottom: 15,
            ),

            child: ListTile(

              title: Text(
                ikan["nama_ikan"],
              ),

              subtitle: Column(

                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  Text(
                    "Kategori : ${ikan["kategori"]}",
                  ),

                  Text(
                    "Jumlah : ${ikan["jumlah"]}",
                  ),

                  Text(
                    "Harga : ${rupiah.format(int.tryParse(ikan["harga"].toString()) ?? 0)}",
                  ),

                  Text(
                    "Agen : ${ikan["nama_lengkap"]}",
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}