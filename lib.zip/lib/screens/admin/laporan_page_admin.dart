import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

class LaporanPage extends StatefulWidget {
  const LaporanPage({super.key});

  @override
  State<LaporanPage> createState() =>
      _LaporanPageState();
}

class _LaporanPageState
    extends State<LaporanPage> {

  int totalUser = 0;
  int totalIkan = 0;
  int totalPesanan = 0;

  Future<void> getLaporan() async {

    final response = await http.get(

      Uri.parse(
        "http://192.168.1.15/appfreashfish/freashfish_api/dashboard_admin.php",
      ),
    );

    final data =
        jsonDecode(response.body);

    setState(() {

      totalUser =
          int.parse(
              data["total_user"]
                  .toString());

      totalIkan =
          int.parse(
              data["total_ikan"]
                  .toString());

      totalPesanan =
          int.parse(
              data["total_pesanan"]
                  .toString());
    });
  }

  @override
  void initState() {
    super.initState();
    getLaporan();
  }

  Widget buildCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {

    return Container(

      margin:
          const EdgeInsets.only(
        bottom: 15,
      ),

      padding:
          const EdgeInsets.all(20),

      decoration:
          BoxDecoration(

        color: Colors.white,

        borderRadius:
            BorderRadius.circular(
                20),

        boxShadow: [

          BoxShadow(

            color: Colors.black
                .withOpacity(0.05),

            blurRadius: 10,
          ),
        ],
      ),

      child: Row(

        children: [

          CircleAvatar(

            radius: 28,

            backgroundColor:
                color.withOpacity(
                    0.15),

            child: Icon(
              icon,
              color: color,
            ),
          ),

          const SizedBox(width: 15),

          Column(

            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [

              Text(
                title,
              ),

              Text(

                value,

                style:
                    GoogleFonts.poppins(

                  fontSize: 22,

                  fontWeight:
                      FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xffF5F8FF),

      appBar: AppBar(

        title: const Text(
          "Laporan",
        ),

        backgroundColor:
            Colors.blue,

        foregroundColor:
            Colors.white,
      ),

      body: Padding(

        padding:
            const EdgeInsets.all(20),

        child: Column(

          children: [

            buildCard(
              "Total User",
              totalUser.toString(),
              Icons.people,
              Colors.blue,
            ),

            buildCard(
              "Total Ikan",
              totalIkan.toString(),
              Icons.set_meal,
              Colors.green,
            ),

            buildCard(
              "Total Pesanan",
              totalPesanan.toString(),
              Icons.shopping_cart,
              Colors.orange,
            ),
          ],
        ),
      ),
    );
  }
}