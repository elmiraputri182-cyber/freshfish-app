import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
class DataIkanAdminPage extends StatefulWidget {
  const DataIkanAdminPage({super.key});

  @override
  State<DataIkanAdminPage> createState() =>
      _DataIkanAdminPageState();
}

class _DataIkanAdminPageState
    extends State<DataIkanAdminPage> {

    final rupiah = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  List dataIkan = [];

  Future<void> getDataIkan() async {

    try {

      final response = await http.get(

        Uri.parse(
          "http://192.168.1.15/appfreashfish/freashfish_api/get_data_ikan_admin.php",
        ),
      );

      setState(() {

        dataIkan =
            jsonDecode(response.body);

      });

    } catch (e) {

      print("ERROR IKAN = $e");

    }
  }

  Future<void> hapusIkan(
    String idIkan,
  ) async {

    try {

      final response = await http.post(

        Uri.parse(
          "http://192.168.1.15/appfreashfish/freashfish_api/hapus_ikan_admin.php",
        ),

        body: {
          "id_ikan": idIkan,
        },
      );

      final data =
          jsonDecode(response.body);

      if(data["success"] == true){

        getDataIkan();

        if(!mounted) return;

        ScaffoldMessenger.of(context)
            .showSnackBar(

          const SnackBar(
            content: Text(
              "Ikan berhasil dihapus",
            ),
          ),
        );
      }

    } catch (e) {

      print(e);

    }
  }

  @override
  void initState() {
    super.initState();
    getDataIkan();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xffF5F8FF),

      appBar: AppBar(

        title: Text(

          "Data Ikan",

          style:
              GoogleFonts.poppins(
            fontWeight:
                FontWeight.bold,
          ),
        ),

        backgroundColor:
            Colors.blue,

        foregroundColor:
            Colors.white,
      ),

      body: dataIkan.isEmpty

          ? const Center(
              child:
                  CircularProgressIndicator(),
            )

          : ListView.builder(

              padding:
                  const EdgeInsets.all(20),

              itemCount:
                  dataIkan.length,

              itemBuilder:
                  (context,index){

                final ikan =
                    dataIkan[index];

                return Container(

                  margin:
                      const EdgeInsets.only(
                    bottom: 15,
                  ),

                  decoration:
                      BoxDecoration(

                    color:
                        Colors.white,

                    borderRadius:
                        BorderRadius
                            .circular(
                      20,
                    ),

                    boxShadow: [

                      BoxShadow(

                        color: Colors
                            .black
                            .withOpacity(
                          0.05,
                        ),

                        blurRadius:
                            10,
                      ),
                    ],
                  ),

                  child: Column(

                    children: [

                      if(ikan["foto_ikan"] !=
                              null &&
                          ikan["foto_ikan"] !=
                              "")

                        ClipRRect(

                          borderRadius:
                              const BorderRadius.only(

                            topLeft:
                                Radius.circular(
                                    20),

                            topRight:
                                Radius.circular(
                                    20),
                          ),

                          child:
                              Image.network(

                            "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${ikan["foto_ikan"]}",

                            height: 180,

                            width:
                                double.infinity,

                            fit: BoxFit.cover,
                          ),
                        ),

                      Padding(

                        padding:
                            const EdgeInsets.all(
                          15,
                        ),

                        child: Column(

                          crossAxisAlignment:
                              CrossAxisAlignment
                                  .start,

                          children: [

                            Text(

                              ikan["nama_ikan"],

                              style:
                                  GoogleFonts
                                      .poppins(

                                fontSize: 18,

                                fontWeight:
                                    FontWeight
                                        .bold,
                              ),
                            ),

                            const SizedBox(
                                height: 5),

                            Text(
                              "Kategori : ${ikan["kategori"]}",
                            ),

                            Text(
                              "Jumlah : ${ikan["jumlah"]} Kg",
                            ),

                            Text(
                              "Harga : ${rupiah.format(int.tryParse(ikan["harga"].toString()) ?? 0)}",
                            ),

                            Text(
                              "Agen : ${ikan["nama_lengkap"]}",
                            ),

                            const SizedBox(
                                height: 15),

                            SizedBox(

                              width:
                                  double.infinity,

                              child:
                                  ElevatedButton.icon(

                                style:
                                    ElevatedButton
                                        .styleFrom(

                                  backgroundColor:
                                      Colors.red,
                                ),

                                onPressed: () {

                                  hapusIkan(

                                    ikan["id_ikan"]
                                        .toString(),
                                  );
                                },

                                icon: const Icon(
                                  Icons.delete,
                                  color:
                                      Colors.white,
                                ),

                                label: const Text(

                                  "Hapus Ikan",

                                  style:
                                      TextStyle(
                                    color:
                                        Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}