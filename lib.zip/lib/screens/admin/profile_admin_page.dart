import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../auth/login_page.dart';

class ProfileAdminPage extends StatefulWidget {
  const ProfileAdminPage({super.key});

  @override
  State<ProfileAdminPage> createState() =>
      _ProfileAdminPageState();
}

class _ProfileAdminPageState
    extends State<ProfileAdminPage> {

  String nama = "-";
  String username = "-";
  String role = "-";

  Future<void> getProfile() async {

    final prefs =
        await SharedPreferences.getInstance();

    setState(() {

      nama =
          prefs.getString(
                "nama_lengkap",
              ) ??
              "-";

      username =
          prefs.getString(
                "username",
              ) ??
              "-";

      role =
          prefs.getString(
                "role",
              ) ??
              "-";
    });
  }

  Future<void> logout() async {

    final prefs =
        await SharedPreferences.getInstance();

    await prefs.clear();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(

      context,

      MaterialPageRoute(
        builder: (_) =>
            const LoginPage(),
      ),

      (route) => false,
    );
  }

  @override
  void initState() {
    super.initState();
    getProfile();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xffF5F8FF),

      appBar: AppBar(

        title: Text(

          "Profil Admin",

          style:
              GoogleFonts.poppins(
            fontWeight:
                FontWeight.bold,
          ),
        ),

        backgroundColor:
            Colors.blue,

        foregroundColor:
            Colors.white,
      ),

      body: Padding(

        padding:
            const EdgeInsets.all(20),

        child: Column(

          children: [

            const SizedBox(height: 30),

            CircleAvatar(

              radius: 55,

              backgroundColor:
                  Colors.blue
                      .withOpacity(0.1),

              child: const Icon(

                Icons.admin_panel_settings,

                size: 55,

                color: Colors.blue,
              ),
            ),

            const SizedBox(height: 20),

            Text(

              nama,

              style:
                  GoogleFonts.poppins(

                fontSize: 22,

                fontWeight:
                    FontWeight.bold,
              ),
            ),

            Text(

              role.toUpperCase(),

              style:
                  GoogleFonts.poppins(

                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 30),

            buildInfoCard(
              "Username",
              username,
              Icons.person,
            ),

            const SizedBox(height: 15),

            buildInfoCard(
              "Role",
              role,
              Icons.security,
            ),

            const Spacer(),

            SizedBox(

              width: double.infinity,
              height: 55,

              child: ElevatedButton.icon(

                style:
                    ElevatedButton.styleFrom(

                  backgroundColor:
                      Colors.red,

                  shape:
                      RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(
                            15),
                  ),
                ),

                onPressed: logout,

                icon: const Icon(
                  Icons.logout,
                  color: Colors.white,
                ),

                label: Text(

                  "LOGOUT",

                  style:
                      GoogleFonts.poppins(

                    color: Colors.white,

                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildInfoCard(
    String title,
    String value,
    IconData icon,
  ) {

    return Container(

      padding:
          const EdgeInsets.all(18),

      decoration:
          BoxDecoration(

        color: Colors.white,

        borderRadius:
            BorderRadius.circular(20),

        boxShadow: [

          BoxShadow(

            color: Colors.black
                .withOpacity(0.05),

            blurRadius: 10,
          ),
        ],
      ),

      child: Row(

        children: [

          CircleAvatar(

            backgroundColor:
                Colors.blue
                    .withOpacity(0.1),

            child: Icon(
              icon,
              color: Colors.blue,
            ),
          ),

          const SizedBox(width: 15),

          Expanded(

            child: Column(

              crossAxisAlignment:
                  CrossAxisAlignment
                      .start,

              children: [

                Text(

                  title,

                  style:
                      GoogleFonts.poppins(

                    color:
                        Colors.grey,
                  ),
                ),

                Text(

                  value,

                  style:
                      GoogleFonts.poppins(

                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}