import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'data_user_page.dart';
import 'data_ikan_admin_page.dart';
import 'data_pesanan_page.dart';
import 'profile_admin_page.dart';

class AdminDashboardPage extends StatefulWidget {
  const AdminDashboardPage({super.key});

  @override
  State<AdminDashboardPage> createState() =>
      _AdminDashboardPageState();
}

class _AdminDashboardPageState
    extends State<AdminDashboardPage> {

  int totalUser = 0;
  int totalIkan = 0;
  int totalPesanan = 0;

  Future<void> getDashboard() async {

    try {

      final response = await http.get(

        Uri.parse(
          "http://192.168.1.15/appfreashfish/freashfish_api/dashboard_admin.php",
        ),
      );

      final data =
          jsonDecode(response.body);

      setState(() {

        totalUser = int.parse(
          data["total_user"].toString(),
        );

        totalIkan = int.parse(
          data["total_ikan"].toString(),
        );

        totalPesanan = int.parse(
          data["total_pesanan"].toString(),
        );
      });

    } catch (e) {

      print(
        "ERROR DASHBOARD = $e",
      );
    }
  }

  @override
  void initState() {
    super.initState();
    getDashboard();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xffF5F8FF),

      appBar: AppBar(

        title: Text(

          "Dashboard Admin",

          style:
              GoogleFonts.poppins(
            fontWeight:
                FontWeight.bold,
          ),
        ),

        backgroundColor:
            Colors.blue,

        foregroundColor:
            Colors.white,
      ),

      body: SingleChildScrollView(

        padding:
            const EdgeInsets.all(20),

        child: Column(

          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [

            Text(

              "Selamat Datang Admin 👋",

              style:
                  GoogleFonts.poppins(

                fontSize: 22,

                fontWeight:
                    FontWeight.bold,
              ),
            ),

            const SizedBox(height: 25),

            Row(

              children: [

                Expanded(

                  child: statistikCard(

                    "Total User",

                    totalUser.toString(),

                    Icons.people,

                    Colors.blue,
                  ),
                ),

                const SizedBox(width: 15),

                Expanded(

                  child: statistikCard(

                    "Total Ikan",

                    totalIkan.toString(),

                    Icons.set_meal,

                    Colors.green,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 15),

            statistikCard(

              "Total Pesanan",

              totalPesanan.toString(),

              Icons.shopping_cart,

              Colors.orange,
            ),

            const SizedBox(height: 30),

            Text(

              "Menu Admin",

              style:
                  GoogleFonts.poppins(

                fontSize: 18,

                fontWeight:
                    FontWeight.bold,
              ),
            ),

            const SizedBox(height: 15),

            GridView.count(

              shrinkWrap: true,

              physics:
                  const NeverScrollableScrollPhysics(),

              crossAxisCount: 2,

              crossAxisSpacing: 15,

              mainAxisSpacing: 15,

              children: [

                menuCard(

                  context,

                  "Data User",

                  Icons.people,

                  Colors.blue,

                  const DataUserPage(),
                ),

                menuCard(

                  context,

                  "Data Ikan",

                  Icons.set_meal,

                  Colors.green,

                  const DataIkanAdminPage(),
                ),

                menuCard(

                  context,

                  "Pesanan",

                  Icons.shopping_cart,

                  Colors.orange,

                  const DataPesananPage(),
                ),

                menuCard(

                  context,

                  "Profil",

                  Icons.person,

                  Colors.red,

                  const ProfileAdminPage(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget statistikCard(

    String title,

    String value,

    IconData icon,

    Color color,

  ) {

    return Container(

      padding:
          const EdgeInsets.all(18),

      decoration: BoxDecoration(

        color: Colors.white,

        borderRadius:
            BorderRadius.circular(20),

        boxShadow: [

          BoxShadow(

            color:
                Colors.black.withOpacity(
              0.05,
            ),

            blurRadius: 10,
          ),
        ],
      ),

      child: Column(

        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [

          Icon(

            icon,

            color: color,

            size: 35,
          ),

          const SizedBox(height: 10),

          Text(

            value,

            style:
                GoogleFonts.poppins(

              fontSize: 28,

              fontWeight:
                  FontWeight.bold,
            ),
          ),

          Text(
            title,
          ),
        ],
      ),
    );
  }

  Widget menuCard(

    BuildContext context,

    String title,

    IconData icon,

    Color color,

    Widget page,

  ) {

    return InkWell(

      onTap: () {

        Navigator.push(

          context,

          MaterialPageRoute(
            builder: (_) => page,
          ),
        );
      },

      child: Container(

        decoration:
            BoxDecoration(

          color: Colors.white,

          borderRadius:
              BorderRadius.circular(
            20,
          ),

          boxShadow: [

            BoxShadow(

              color:
                  Colors.black.withOpacity(
                0.05,
              ),

              blurRadius: 10,
            ),
          ],
        ),

        child: Column(

          mainAxisAlignment:
              MainAxisAlignment.center,

          children: [

            CircleAvatar(

              radius: 28,

              backgroundColor:
                  color.withOpacity(
                0.15,
              ),

              child: Icon(

                icon,

                color: color,

                size: 30,
              ),
            ),

            const SizedBox(height: 12),

            Text(

              title,

              style:
                  GoogleFonts.poppins(

                fontWeight:
                    FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}