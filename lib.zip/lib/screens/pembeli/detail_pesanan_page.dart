import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class DetailPesananPage extends StatelessWidget {
    final rupiah = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );
  final Map data;

  DetailPesananPage({
    super.key,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {

    Color warnaStatus = Colors.orange;

    if (data["status"] == "Diproses") {
      warnaStatus = Colors.blue;
    } else if (data["status"] == "Selesai") {
      warnaStatus = Colors.green;
    } else if (data["status"] == "Dibatalkan") {
      warnaStatus = Colors.red;
    }

    return Scaffold(

      backgroundColor: const Color(0xffF4F8FC),

      appBar: AppBar(

        backgroundColor: Colors.blue,

        foregroundColor: Colors.white,

        elevation: 0,

        title: Text(
          "Detail Pesanan",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: SingleChildScrollView(

        padding: const EdgeInsets.all(20),

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            /// FOTO IKAN
            Center(

              child: ClipRRect(

                borderRadius: BorderRadius.circular(20),

                child: Image.network(

                  "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${data["foto_ikan"]}",

                  height: 220,

                  width: double.infinity,

                  fit: BoxFit.cover,

                  errorBuilder: (_, __, ___) {

                    return Container(

                      height: 220,

                      color: Colors.grey.shade300,

                      child: const Icon(
                        Icons.image,
                        size: 70,
                      ),
                    );
                  },
                ),
              ),
            ),

            const SizedBox(height: 25),

            Text(

              data["nama_ikan"],

              style: GoogleFonts.poppins(

                fontSize: 28,

                fontWeight: FontWeight.bold,

              ),
            ),

            const SizedBox(height: 10),

            Container(

              padding: const EdgeInsets.symmetric(

                horizontal: 18,

                vertical: 8,

              ),

              decoration: BoxDecoration(

                color: warnaStatus.withOpacity(.15),

                borderRadius: BorderRadius.circular(20),

              ),

              child: Text(

                data["status"],

                style: GoogleFonts.poppins(

                  color: warnaStatus,

                  fontWeight: FontWeight.bold,

                ),
              ),
            ),

            const SizedBox(height: 30),

            Container(

              padding: const EdgeInsets.all(20),

              decoration: BoxDecoration(

                color: Colors.white,

                borderRadius: BorderRadius.circular(20),

                boxShadow: [

                  BoxShadow(

                    color: Colors.black.withOpacity(.05),

                    blurRadius: 10,

                  )

                ],
              ),

              child: Column(

                children: [

                  itemDetail(

                    "ID Pesanan",

                    "#${data["id_pesanan"]}",

                  ),

                  itemDetail(

                    "Tanggal",

                    data["tanggal"],

                  ),

                  itemDetail(

                    "Jumlah",

                    "${data["jumlah_kg"]} Kg",

                  ),

                  itemDetail(

                    "Harga",

                    rupiah.format(
                      int.tryParse(data["harga"].toString()) ?? 0,
                    ),

                  ),

                  itemDetail(

                    "Total",

                    rupiah.format(
                      int.tryParse(data["total_harga"].toString()) ?? 0,
                    ),

                  ),

                  itemDetail(

                    "Metode Pembayaran",

                    data["metode_pembayaran"],

                  ),

                  itemDetail(

                    "Pengambilan",

                    data["metode_pengambilan"],

                  ),

                  itemDetail(

                    "Nama Agen",

                    data["nama_agen"] ?? "-",

                  ),

                ],
              ),
            ),

            const SizedBox(height: 25),

            Text(

              "Status Pesanan",

              style: GoogleFonts.poppins(

                fontWeight: FontWeight.bold,

                fontSize: 18,

              ),
            ),

            const SizedBox(height: 15),

            statusItem(

              "Pesanan dibuat",

              true,

              Colors.green,

            ),

            statusItem(

              "Menunggu konfirmasi",

              data["status"] == "Menunggu" ||

                      data["status"] == "Diproses" ||

                      data["status"] == "Selesai",

              Colors.orange,

            ),

            statusItem(

              "Diproses Agen",

              data["status"] == "Diproses" ||

                      data["status"] == "Selesai",

              Colors.blue,

            ),

            statusItem(

              "Pesanan selesai",

              data["status"] == "Selesai",

              Colors.green,

            ),

            const SizedBox(height: 40),

            SizedBox(

              width: double.infinity,

              height: 55,

              child: ElevatedButton(

                style: ElevatedButton.styleFrom(

                  backgroundColor: Colors.blue,

                  shape: RoundedRectangleBorder(

                    borderRadius: BorderRadius.circular(15),

                  ),
                ),

                onPressed: () {

                  Navigator.pop(context);

                },

                child: Text(

                  "Kembali",

                  style: GoogleFonts.poppins(

                    color: Colors.white,

                    fontWeight: FontWeight.bold,

                    fontSize: 16,

                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget itemDetail(String title, String value) {

    return Padding(

      padding: const EdgeInsets.symmetric(vertical: 10),

      child: Row(

        mainAxisAlignment: MainAxisAlignment.spaceBetween,

        children: [

          Text(

            title,

            style: GoogleFonts.poppins(

              color: Colors.grey,

              fontSize: 14,

            ),
          ),

          Flexible(

            child: Text(

              value,

              textAlign: TextAlign.end,

              style: GoogleFonts.poppins(

                fontWeight: FontWeight.bold,

                fontSize: 15,

              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget statusItem(

    String title,

    bool aktif,

    Color warna,

  ) {

    return Padding(

      padding: const EdgeInsets.only(bottom: 15),

      child: Row(

        children: [

          CircleAvatar(

            radius: 10,

            backgroundColor:

                aktif ? warna : Colors.grey.shade300,

            child: aktif

                ? const Icon(

                    Icons.check,

                    size: 12,

                    color: Colors.white,

                  )

                : null,
          ),

          const SizedBox(width: 15),

          Text(

            title,

            style: GoogleFonts.poppins(

              fontWeight: FontWeight.w500,

            ),
          ),
        ],
      ),
    );
  }
}