import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfilPage extends StatefulWidget {

  const ProfilPage({super.key});

  @override
  State<ProfilPage> createState() =>
      _ProfilPageState();
}

class _ProfilPageState
    extends State<ProfilPage> {

  String nama = "";
  String username = "";
  String noHp = "";
  String alamat = "";

  @override
  void initState() {
    super.initState();
    getSession();
  }

  Future<void> getSession() async {

    final pref =
        await SharedPreferences.getInstance();

    setState(() {

      nama =
          pref.getString("nama") ?? "";

      username =
          pref.getString("username") ?? "";

      noHp =
          pref.getString("no_hp") ?? "";

      alamat =
          pref.getString("alamat") ?? "";
    });
  }

  Future<void> logout() async {

    final pref =
        await SharedPreferences.getInstance();

    await pref.clear();

    if (!mounted) return;

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xFFF8FBFF),

      appBar: AppBar(

        title: Text(

          "Profil Saya",

          style:
              GoogleFonts.poppins(
            fontWeight:
                FontWeight.bold,
          ),
        ),

        backgroundColor:
            Colors.blue,

        foregroundColor:
            Colors.white,
      ),

      body: SingleChildScrollView(

        padding:
            const EdgeInsets.all(25),

        child: Column(

          children: [

            // FOTO PROFIL
            Container(

              height: 120,
              width: 120,

              decoration: BoxDecoration(

                color: Colors.blue
                    .withOpacity(0.1),

                shape: BoxShape.circle,
              ),

              child: const Icon(

                Icons.person,

                size: 70,

                color: Colors.blue,
              ),
            ),

            const SizedBox(height: 20),

            Text(

              nama,

              style:
                  GoogleFonts.poppins(

                fontSize: 24,

                fontWeight:
                    FontWeight.bold,
              ),
            ),

            const SizedBox(height: 5),

            Text(

              username,

              style:
                  GoogleFonts.poppins(
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 35),

            buildItem(
              Icons.phone,
              noHp,
            ),

            buildItem(
              Icons.location_on,
              alamat,
            ),

            buildItem(
              Icons.person_outline,
              "Pembeli",
            ),

            const SizedBox(height: 40),

            SizedBox(

              width: double.infinity,
              height: 55,

              child: ElevatedButton.icon(

                style:
                    ElevatedButton
                        .styleFrom(

                  backgroundColor:
                      Colors.red,

                  shape:
                      RoundedRectangleBorder(

                    borderRadius:
                        BorderRadius.circular(
                            18),
                  ),
                ),

                onPressed: logout,

                icon: const Icon(
                  Icons.logout,
                  color: Colors.white,
                ),

                label: Text(

                  "LOGOUT",

                  style:
                      GoogleFonts.poppins(

                    color: Colors.white,

                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildItem(
    IconData icon,
    String text,
  ) {

    return Container(

      margin:
          const EdgeInsets.only(
        bottom: 18,
      ),

      padding:
          const EdgeInsets.all(18),

      decoration:
          BoxDecoration(

        color: Colors.white,

        borderRadius:
            BorderRadius.circular(
                20),

        boxShadow: [

          BoxShadow(
            color: Colors.blue
                .withOpacity(0.08),

            blurRadius: 15,

            offset:
                const Offset(0, 8),
          ),
        ],
      ),

      child: Row(

        children: [

          Icon(
            icon,
            color: Colors.blue,
          ),

          const SizedBox(width: 15),

          Expanded(

            child: Text(

              text,

              style:
                  GoogleFonts.poppins(

                fontWeight:
                    FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}