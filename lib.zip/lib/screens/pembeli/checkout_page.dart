import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'payment_page.dart';
import 'package:intl/intl.dart';

class CheckoutPage extends StatefulWidget {

  final Map ikan;

  const CheckoutPage({
    super.key,
    required this.ikan,
  });

  @override
  State<CheckoutPage> createState() =>
      _CheckoutPageState();
}

class _CheckoutPageState
    extends State<CheckoutPage> {
      final rupiah = NumberFormat.currency(
        locale: 'id_ID',
        symbol: 'Rp ',
        decimalDigits: 0,
      );

  final jumlahController =
      TextEditingController();

  String metodePembayaran =
      "cod";

  String metodePengambilan =
      "ambil_ditempat";

  String metodeTransfer =
      "dana";

  int totalBayar = 0;

  void hitungTotal() {

    int harga =
        int.parse(
      widget.ikan["harga"]
          .toString()
          .split(".")[0],
    );

    int jumlah =
        int.tryParse(
              jumlahController.text,
            ) ??
            0;

    setState(() {

      totalBayar =
          harga * jumlah;
    });
  }

  Future<void> buatPesanan() async {

    final response = await http.post(

      Uri.parse(
        "http://192.168.1.15/appfreashfish/freashfish_api/tambah_pemesanan.php",
      ),

      body: {

        "id_pembeli": "1",

        "id_agen": "1",

        "tanggal_pemesanan":
            DateTime.now()
                .toString(),

        "metode_pengambilan":
            metodePengambilan,

        "metode_pembayaran":
            metodePembayaran,

        "status_pembayaran":
            metodePembayaran == "cod"
                ? "belum_bayar"
                : "berhasil",

        "total_bayar":
            totalBayar.toString(),

        "status_pemesanan":
            metodePembayaran == "cod"
                ? "diproses"
                : "menunggu_pembayaran",
      },
    );

    final data =
        jsonDecode(response.body);

    if(data["success"] == true){

      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(

        const SnackBar(
          content: Text(
            "Pesanan berhasil dibuat",
          ),
        ),
      );

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xFFF8FBFF),

      appBar: AppBar(

        title: Text(

          "Checkout",

          style:
              GoogleFonts.poppins(
            fontWeight:
                FontWeight.bold,
          ),
        ),

        backgroundColor:
            Colors.blue,

        foregroundColor:
            Colors.white,
      ),

      body: SingleChildScrollView(

        padding:
            const EdgeInsets.all(25),

        child: Column(

          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [

            Container(

              padding:
                  const EdgeInsets.all(
                20,
              ),

              decoration: BoxDecoration(

                color: Colors.white,

                borderRadius:
                    BorderRadius.circular(
                        25),

                boxShadow: [

                  BoxShadow(
                    color: Colors.blue
                        .withOpacity(0.08),

                    blurRadius: 15,

                    offset:
                        const Offset(
                            0, 8),
                  ),
                ],
              ),

              child: Column(

                crossAxisAlignment:
                    CrossAxisAlignment
                        .start,

                children: [

                  Text(

                    widget
                        .ikan["nama_ikan"],

                    style:
                        GoogleFonts
                            .poppins(

                      fontSize: 20,

                      fontWeight:
                          FontWeight
                              .bold,
                    ),
                  ),

                  const SizedBox(
                      height: 10),

                  Text(

                    "Harga : ${rupiah.format(
                      int.tryParse(widget.ikan["harga"].toString()) ?? 0,
                    )}",

                    style: GoogleFonts.poppins(
                      fontSize: 15,
                    ),

                  ),

                  const SizedBox(
                      height: 20),

                  TextField(

                    controller:
                        jumlahController,

                    keyboardType:
                        TextInputType
                            .number,

                    onChanged: (value) {

                      hitungTotal();
                    },

                    decoration:
                        InputDecoration(

                      hintText:
                          "Jumlah beli",

                      filled: true,

                      fillColor:
                          Colors.blue
                              .withOpacity(
                                  0.05),

                      border:
                          OutlineInputBorder(

                        borderRadius:
                            BorderRadius
                                .circular(
                                    18),

                        borderSide:
                            BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(
                      height: 20),

                  // METODE PEMBAYARAN
                  Text(

                    "Metode Pembayaran",

                    style:
                        GoogleFonts
                            .poppins(

                      fontWeight:
                          FontWeight.w600,
                    ),
                  ),

                  const SizedBox(
                      height: 10),

                  Container(

                    padding:
                        const EdgeInsets
                            .symmetric(
                      horizontal: 15,
                    ),

                    decoration:
                        BoxDecoration(

                      color: Colors
                          .blue
                          .withOpacity(
                              0.05),

                      borderRadius:
                          BorderRadius
                              .circular(
                                  18),
                    ),

                    child:
                        DropdownButton<
                            String>(

                      value:
                          metodePembayaran,

                      isExpanded:
                          true,

                      underline:
                          const SizedBox(),

                      items: const [

                        DropdownMenuItem(

                          value: "cod",

                          child: Text(
                            "COD (Bayar Saat Diterima)",
                          ),
                        ),

                        DropdownMenuItem(

                          value:
                              "transfer",

                          child: Text(
                            "Transfer Bank / E-Wallet",
                          ),
                        ),
                      ],

                      onChanged:
                          (value){

                        setState(() {

                          metodePembayaran =
                              value!;
                        });
                      },
                    ),
                  ),

                  // JIKA TRANSFER
                  if(metodePembayaran ==
                      "transfer")

                    Column(

                      crossAxisAlignment:
                          CrossAxisAlignment
                              .start,

                      children: [

                        const SizedBox(height: 20),
                        SizedBox(

                          width: double.infinity,

                          height: 55,

                          child: ElevatedButton(

                            style:
                                ElevatedButton.styleFrom(

                              backgroundColor:
                                  Colors.blue,

                              shape:
                                  RoundedRectangleBorder(

                                borderRadius:
                                    BorderRadius.circular(
                                        18),
                              ),
                            ),

                            onPressed: () async {

                              // VALIDASI JUMLAH
                              if(jumlahController.text.isEmpty){

                                ScaffoldMessenger.of(context)
                                    .showSnackBar(

                                  const SnackBar(

                                    content: Text(
                                      "Jumlah beli wajib diisi",
                                    ),
                                  ),
                                );

                                return;
                              }

                              // HITUNG TOTAL DULU
                              hitungTotal();

                              // JIKA COD
                              if(metodePembayaran ==
                                  "cod"){

                                await buatPesanan();

                              }

                              // JIKA TRANSFER
                              else{

                                Navigator.push(

                                  context,

                                  MaterialPageRoute(

                                    builder: (_) =>
                                        PaymentPage(

                                      totalBayar:
                                          totalBayar,
                                    ),
                                  ),
                                );
                              }
                            },

                            child: Text(

                              metodePembayaran ==
                                      "cod"

                                  ? "BUAT PESANAN"

                                  : "LANJUTKAN PEMBAYARAN",

                              style:
                                  GoogleFonts
                                      .poppins(

                                color:
                                    Colors.white,

                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        Text(

                          "Pilih Transfer",

                          style:
                              GoogleFonts
                                  .poppins(

                            fontWeight:
                                FontWeight
                                    .w600,
                          ),
                        ),

                        const SizedBox(
                            height: 10),

                        Container(

                          padding:
                              const EdgeInsets
                                  .symmetric(
                            horizontal: 15,
                          ),

                          decoration:
                              BoxDecoration(

                            color: Colors
                                .blue
                                .withOpacity(
                                    0.05),

                            borderRadius:
                                BorderRadius
                                    .circular(
                                        18),
                          ),

                          child:
                              DropdownButton<
                                  String>(

                            value:
                                metodeTransfer,

                            isExpanded:
                                true,

                            underline:
                                const SizedBox(),

                            items: const [

                              DropdownMenuItem(
                                value: "dana",
                                child:
                                    Text("DANA"),
                              ),

                              DropdownMenuItem(
                                value: "ovo",
                                child:
                                    Text("OVO"),
                              ),

                              DropdownMenuItem(
                                value: "bca",
                                child: Text(
                                  "M-Banking BCA",
                                ),
                              ),

                              DropdownMenuItem(
                                value: "bri",
                                child: Text(
                                  "M-Banking BRI",
                                ),
                              ),
                            ],

                            onChanged:
                                (value){

                              setState(() {

                                metodeTransfer =
                                    value!;
                              });
                            },
                          ),
                        ),

                        const SizedBox(
                            height: 20),

                        Container(

                          width:
                              double.infinity,

                          padding:
                              const EdgeInsets
                                  .all(18),

                          decoration:
                              BoxDecoration(

                            color: Colors
                                .orange
                                .withOpacity(
                                    0.1),

                            borderRadius:
                                BorderRadius
                                    .circular(
                                        18),
                          ),

                          child: Column(

                            children: [

                              Text(

                                "Lakukan Pembayaran Ke",

                                style:
                                    GoogleFonts
                                        .poppins(
                                  color:
                                      Colors.grey,
                                ),
                              ),

                              const SizedBox(
                                  height: 8),

                              Text(

                                "0812-3456-7890",

                                style:
                                    GoogleFonts
                                        .poppins(

                                  fontSize: 22,

                                  fontWeight:
                                      FontWeight
                                          .bold,

                                  color:
                                      Colors
                                          .orange,
                                ),
                              ),

                              const SizedBox(
                                  height: 8),

                              Text(

                                "Batas pembayaran 5 menit",

                                style:
                                    GoogleFonts
                                        .poppins(

                                  fontSize: 12,

                                  color:
                                      Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                  const SizedBox(
                      height: 20),

                  // SISTEM PENGAMBILAN
                  Text(

                    "Sistem Pengambilan",

                    style:
                        GoogleFonts
                            .poppins(

                      fontWeight:
                          FontWeight.w600,
                    ),
                  ),

                  const SizedBox(
                      height: 10),

                  Container(

                    padding:
                        const EdgeInsets
                            .symmetric(
                      horizontal: 15,
                    ),

                    decoration:
                        BoxDecoration(

                      color: Colors
                          .blue
                          .withOpacity(
                              0.05),

                      borderRadius:
                          BorderRadius
                              .circular(
                                  18),
                    ),

                    child:
                        DropdownButton<
                            String>(

                      value:
                          metodePengambilan,

                      isExpanded:
                          true,

                      underline:
                          const SizedBox(),

                      items: const [

                        DropdownMenuItem(

                          value:
                              "ambil_ditempat",

                          child: Text(
                            "Ambil di Dermaga",
                          ),
                        ),

                        DropdownMenuItem(

                          value: "diantar",

                          child: Text(
                            "Diantar Agen",
                          ),
                        ),
                      ],

                      onChanged:
                          (value){

                        setState(() {

                          metodePengambilan =
                              value!;
                        });
                      },
                    ),
                  ),

                  const SizedBox(
                      height: 25),

                  Container(

                    width:
                        double.infinity,

                    padding:
                        const EdgeInsets
                            .all(18),

                    decoration:
                        BoxDecoration(

                      color: Colors
                          .green
                          .withOpacity(
                              0.1),

                      borderRadius:
                          BorderRadius
                              .circular(
                                  18),
                    ),

                    child: Column(

                      children: [

                        Text(

                          "Total Bayar",

                          style:
                              GoogleFonts
                                  .poppins(
                            color:
                                Colors.grey,
                          ),
                        ),

                        const SizedBox(
                            height: 5),

                        Text(

                          rupiah.format(
                            totalBayar,
                          ),

                          style: GoogleFonts.poppins(

                            fontSize: 24,

                            fontWeight: FontWeight.bold,

                            color: Colors.green,

                          ),

                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            SizedBox(

              width:
                  double.infinity,

              height: 55,

              child: ElevatedButton(

                style:
                    ElevatedButton
                        .styleFrom(

                  backgroundColor:
                      Colors.blue,

                  shape:
                      RoundedRectangleBorder(

                    borderRadius:
                        BorderRadius
                            .circular(
                                18),
                  ),
                ),

                onPressed: () {

                  if(metodePembayaran ==
                      "cod"){

                    buatPesanan();

                  }else{

                    Navigator.push(

                      context,

                      MaterialPageRoute(

                        builder: (_) =>
                            PaymentPage(

                          totalBayar:
                              totalBayar,
                        ),
                      ),
                    );
                  }
                },
                

                child: Text(

                  metodePembayaran ==
                          "cod"

                      ? "BUAT PESANAN"

                      : "LANJUTKAN PEMBAYARAN",

                  style:
                      GoogleFonts
                          .poppins(

                    color:
                        Colors.white,

                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}