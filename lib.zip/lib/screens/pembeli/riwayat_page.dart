import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'detail_pesanan_page.dart';
import 'package:intl/intl.dart';

class RiwayatPage extends StatefulWidget {

  const RiwayatPage({super.key});

  @override
  State<RiwayatPage> createState() =>
      _RiwayatPageState();
}

class _RiwayatPageState
    extends State<RiwayatPage> {
      final rupiah = NumberFormat.currency(
        locale: 'id_ID',
        symbol: 'Rp ',
        decimalDigits: 0,
      );

  List pesanan = [];

  @override
  void initState() {

    super.initState();

    getPesanan();
  }

 Future getPesanan() async {

  final pref =
      await SharedPreferences.getInstance();

  final idUser =
      pref.getString("id_user");

  final response =
      await http.get(

    Uri.parse(
      "http://192.168.1.15/appfreashfish/freashfish_api/get_riwayat_pembeli.php?id_user=$idUser",
    ),
  );

  print("ID USER = $idUser");
  print("BODY = ${response.body}");

  final hasil = jsonDecode(response.body);

  setState(() {
    pesanan = hasil["data"];
  });
}

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: const Color(0xffF3F7FB),

      appBar: AppBar(
      elevation: 0,

      centerTitle: true,

      backgroundColor: const Color(0xff2196F3),

      foregroundColor: Colors.white,

      title: Text(

        "Riwayat Pesanan",
        
        style: GoogleFonts.poppins(

          fontSize: 24,
          
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
      body: pesanan.isEmpty

          ? Center(

              child: Text(

                "Belum ada pesanan",

                style:
                    GoogleFonts.poppins(
                  fontSize: 16,
                ),
              ),
            )

          : ListView.builder(

              padding:
                  const EdgeInsets.all(
                20,
              ),

              itemCount:
                  pesanan.length,

              itemBuilder:
                  (context, index){
                
                final item =
                    pesanan[index];
                Color warnaStatus;

                if (item["status"] == "Menunggu") {
                  warnaStatus = Colors.orange;
                } else if (item["status"] == "Diproses") {
                  warnaStatus = Colors.blue;
                } else if (item["status"] == "Selesai") {
                  warnaStatus = Colors.green;
                } else {
                  warnaStatus = Colors.red;
                }
                return Container(
                  margin: const EdgeInsets.only(bottom: 18),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(.05),
                        blurRadius: 12,
                        offset: const Offset(0, 5),
                      )
                    ],
                  ),

                  child: Column(

                    children: [

                      Row(

                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [

                          /// FOTO IKAN

                          ClipRRect(

                            borderRadius: BorderRadius.circular(16),

                            child: Image.network(

                              "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${item["foto_ikan"]}",

                              width: 95,

                              height: 95,

                              fit: BoxFit.cover,

                              errorBuilder: (_, __, ___) {

                                return Container(

                                  width: 95,

                                  height: 95,

                                  color: Colors.grey.shade200,

                                  child: const Icon(Icons.image,size:40),

                                );

                              },

                            ),

                          ),

                          const SizedBox(width:15),

                          Expanded(

                            child: Column(

                              crossAxisAlignment: CrossAxisAlignment.start,

                              children: [

                                Text(

                                  item["nama_ikan"],

                                  maxLines: 2,

                                  overflow: TextOverflow.ellipsis,

                                  style: GoogleFonts.poppins(

                                    fontSize: 20,

                                    fontWeight: FontWeight.bold,

                                  ),

                                ),

                                const SizedBox(height:6),

                                Row(

                                  children: [

                                    Icon(

                                      Icons.scale,

                                      size:16,

                                      color: Colors.grey.shade600,

                                    ),

                                    const SizedBox(width:5),

                                    Text(

                                      "${item["jumlah_kg"]} Kg",

                                      style: GoogleFonts.poppins(

                                        color: Colors.grey.shade700,

                                      ),

                                    )

                                  ],

                                ),

                                const SizedBox(height:5),

                                Row(

                                  children: [

                                    Icon(

                                      Icons.calendar_month,

                                      size:16,

                                      color: Colors.grey.shade600,

                                    ),

                                    const SizedBox(width:5),

                                    Expanded(

                                      child: Text(

                                        item["tanggal"],

                                        style: GoogleFonts.poppins(

                                          fontSize:12,

                                          color: Colors.grey,

                                        ),

                                      ),

                                    )

                                  ],

                                ),

                                const SizedBox(height:12),

                                Text(

                                  rupiah.format(
                                    int.tryParse(item["total_harga"].toString()) ?? 0,
                                  ),

                                  style: GoogleFonts.poppins(

                                    color: Colors.orange,

                                    fontWeight: FontWeight.bold,

                                    fontSize: 24,

                                  ),

                                ),

                              ],

                            ),

                          ),

                        ],

                      ),

                      const SizedBox(height:18),

                      Divider(),

                      const SizedBox(height:8),

                      Row(

                        children: [

                          Container(

                            padding: const EdgeInsets.symmetric(

                              horizontal:16,

                              vertical:8,

                            ),

                            decoration: BoxDecoration(

                              color: warnaStatus.withOpacity(.15),

                              borderRadius: BorderRadius.circular(20),

                            ),

                            child: Text(

                              item["status"],

                              style: GoogleFonts.poppins(

                                color: warnaStatus,

                                fontWeight: FontWeight.bold,

                              ),

                            ),

                          ),

                          const Spacer(),

                          Container(

                            padding: const EdgeInsets.symmetric(

                              horizontal:12,

                              vertical:7,

                            ),

                            decoration: BoxDecoration(

                              color: Colors.blue.shade50,

                              borderRadius: BorderRadius.circular(20),

                            ),

                            child: Row(

                              children: [

                                const Icon(

                                  Icons.payment,

                                  size:16,

                                  color: Colors.blue,

                                ),

                                const SizedBox(width:5),

                                Text(

                                  item["metode_pembayaran"],

                                  style: GoogleFonts.poppins(

                                    fontSize:12,

                                    fontWeight: FontWeight.w500,

                                  ),

                                ),

                              ],

                            ),

                          ),

                        ],

                      ),

                      const SizedBox(height:15),

                      SizedBox(

                        width: double.infinity,

                        child: OutlinedButton.icon(

                          style: OutlinedButton.styleFrom(

                            side: BorderSide(

                              color: Colors.blue.shade300,

                            ),

                            shape: RoundedRectangleBorder(

                              borderRadius: BorderRadius.circular(15),

                            ),

                            padding: const EdgeInsets.symmetric(

                              vertical:13,

                            ),

                          ),

                          onPressed: () {

                            Navigator.push(

                              context,

                              MaterialPageRoute(

                                builder: (_) => DetailPesananPage(

                                  data: item,

                                ),

                              ),

                            );

                          },

                          icon: const Icon(

                            Icons.visibility,

                            color: Colors.blue,

                          ),

                          label: Text(

                            "Lihat Detail Pesanan",

                            style: GoogleFonts.poppins(

                              color: Colors.blue,

                              fontWeight: FontWeight.bold,

                            ),

                          ),

                        ),

                      ),

                    ],

                  ),

                );
              },
            ),
          );
        }
      }