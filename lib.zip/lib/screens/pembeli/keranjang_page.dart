import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

class KeranjangPage extends StatefulWidget {
  const KeranjangPage({super.key});

  @override
  State<KeranjangPage> createState() => _KeranjangPageState();
}

class _KeranjangPageState extends State<KeranjangPage> {

  final rupiah = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  List keranjang = [];

  bool pilihSemua = false;

  double total = 0;

  @override
  void initState() {
    super.initState();
    getKeranjang();
  }

  Future getKeranjang() async {

    final pref = await SharedPreferences.getInstance();

    final idUser = pref.getString("id_user");

    final response = await http.get(

      Uri.parse(

        "http://192.168.1.15/appfreashfish/freashfish_api/get_keranjang.php?id_user=$idUser",

      ),

    );

    final hasil = jsonDecode(response.body);

    setState(() {

      keranjang = hasil["data"];

      for(var item in keranjang){

        item["checked"] = false;

      }

    });

  }

  void hitungTotal(){

    total = 0;

    for(var item in keranjang){

      if(item["checked"]){

        total += double.parse(

          item["subtotal"].toString(),

        );

      }

    }

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: const Color(0xffF5F8FD),

      appBar: AppBar(

        title: Text(

          "Keranjang",

          style: GoogleFonts.poppins(

            fontWeight: FontWeight.bold,

          ),

        ),

        backgroundColor: Colors.blue,

        foregroundColor: Colors.white,

      ),

      body: keranjang.isEmpty

      ? Center(

        child: Text(

          "Keranjang masih kosong",

          style: GoogleFonts.poppins(),

        ),

      )

      : ListView.builder(

        padding: const EdgeInsets.all(15),

        itemCount: keranjang.length,

        itemBuilder: (context,index){

          final item = keranjang[index];

          return Container(

            margin: const EdgeInsets.only(bottom:15),

            padding: const EdgeInsets.all(15),

            decoration: BoxDecoration(

              color: Colors.white,

              borderRadius: BorderRadius.circular(20),

              boxShadow: [

                BoxShadow(

                  color: Colors.black.withOpacity(.05),

                  blurRadius: 10,

                )

              ],

            ),

            child: Row(

              children: [

                Checkbox(

                  value: item["checked"],

                  activeColor: Colors.blue,

                  onChanged: (value){

                    setState(() {

                      item["checked"] = value;

                    });

                    hitungTotal();

                  },

                ),

                ClipRRect(

                  borderRadius: BorderRadius.circular(15),

                  child: Image.network(

                    "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${item["foto_ikan"]}",

                    width: 80,

                    height: 80,

                    fit: BoxFit.cover,

                    errorBuilder: (_,__,___){

                      return Container(

                        width:80,

                        height:80,

                        color: Colors.grey.shade300,

                        child: const Icon(Icons.image),

                      );

                    },

                  ),

                ),

                const SizedBox(width:15),

                Expanded(

                  child: Column(

                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [

                      Text(

                        item["nama_ikan"],

                        style: GoogleFonts.poppins(

                          fontWeight: FontWeight.bold,

                          fontSize:18,

                        ),

                      ),

                      const SizedBox(height:5),

                      Text(

                        "${item["jumlah_kg"]} Kg",

                        style: GoogleFonts.poppins(),

                      ),

                      const SizedBox(height:5),

                      Text(

                      rupiah.format(
                        int.tryParse(item["subtotal"].toString()) ?? 0,
                      ),

                      style: GoogleFonts.poppins(

                        color: Colors.orange,

                        fontWeight: FontWeight.bold,

                        fontSize: 18,

                      ),

                    ),

                    ],

                  ),

                ),

              ],

            ),

          );

        },

      ),

      bottomNavigationBar: Container(

        padding: const EdgeInsets.all(20),

        decoration: const BoxDecoration(

          color: Colors.white,

        ),

        child: Column(

          mainAxisSize: MainAxisSize.min,

          children: [

            Row(

              children: [

                Checkbox(

                  value: pilihSemua,

                  onChanged: (value){

                    setState(() {

                      pilihSemua = value!;

                      for(var item in keranjang){

                        item["checked"] = value;

                      }

                    });

                    hitungTotal();

                  },

                ),

                Text(

                  "Pilih Semua",

                  style: GoogleFonts.poppins(),

                ),

                const Spacer(),

                Text(

                rupiah.format(total),

                style: GoogleFonts.poppins(

                  fontWeight: FontWeight.bold,

                  fontSize: 22,

                  color: Colors.orange,

                ),

              ),

              ],

            ),

            const SizedBox(height:10),

            SizedBox(

              width: double.infinity,

              height:55,

              child: ElevatedButton(

                style: ElevatedButton.styleFrom(

                  backgroundColor: Colors.blue,

                  shape: RoundedRectangleBorder(

                    borderRadius: BorderRadius.circular(15),

                  ),

                ),

                onPressed: (){

                  // checkout

                },

                child: Text(

                  "Checkout",

                  style: GoogleFonts.poppins(

                    color: Colors.white,

                    fontWeight: FontWeight.bold,

                    fontSize:16,

                  ),

                ),

              ),

            )

          ],

        ),

      ),

    );

  }

}