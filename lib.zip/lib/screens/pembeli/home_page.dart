import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'cart_page.dart';
import 'info_harga_page.dart';
import 'profil_page.dart';
import 'riwayat_page.dart';

class HomePage extends StatefulWidget {

  const HomePage({super.key});

  @override
  State<HomePage> createState() =>
      _HomePageState();
}

class _HomePageState
    extends State<HomePage> {

  int currentIndex = 0;

  List ikanList = [];

  @override
  void initState() {

    super.initState();

    getDataIkan();
  }

  Future getDataIkan() async {

    final response = await http.get(

      Uri.parse(
        "http://192.168.1.15/appfreashfish/freashfish_api/get_data_ikan.php",
      ),
    );

    setState(() {

      ikanList =
          jsonDecode(response.body);
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xFFF8FBFF),

      body: SafeArea(

        child: Stack(

          children: [

            // DEKORASI ATAS
            Positioned(

              top: -70,
              right: -60,

              child: Container(

                height: 220,
                width: 220,

                decoration: BoxDecoration(

                  color: Colors.blue
                      .withOpacity(0.08),

                  shape: BoxShape.circle,
                ),
              ),
            ),

            // DEKORASI BAWAH
            Positioned(

              bottom: -100,
              left: -80,

              child: Container(

                height: 220,
                width: 220,

                decoration: BoxDecoration(

                  color: Colors.lightBlue
                      .withOpacity(0.08),

                  shape: BoxShape.circle,
                ),
              ),
            ),

            SingleChildScrollView(

              padding:
                  const EdgeInsets.all(25),

              child: Column(

                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  // HEADER
                  Row(

                    mainAxisAlignment:
                        MainAxisAlignment
                            .spaceBetween,

                    children: [

                      Column(

                        crossAxisAlignment:
                            CrossAxisAlignment
                                .start,

                        children: [

                          Text(

                            "FreshFish",

                            style:
                                GoogleFonts
                                    .poppins(

                              fontSize: 28,

                              fontWeight:
                                  FontWeight
                                      .bold,

                              color:
                                  const Color(
                                      0xFF1565C0),
                            ),
                          ),

                          const SizedBox(
                              height: 5),

                          Text(

                            "Ikan segar langsung dari nelayan",

                            style:
                                GoogleFonts
                                    .poppins(

                              color:
                                  Colors.grey,
                            ),
                          ),
                        ],
                      ),

                      GestureDetector(

                        onTap: () {

                          Navigator.push(

                            context,

                            MaterialPageRoute(

                              builder: (_) =>
                                  const CartPage(),
                            ),
                          );
                        },

                        child: Container(

                          padding:
                              const EdgeInsets
                                  .all(14),

                          decoration:
                              BoxDecoration(

                            color: Colors.white,

                            borderRadius:
                                BorderRadius
                                    .circular(
                                        18),

                            boxShadow: [

                              BoxShadow(

                                color: Colors
                                    .black
                                    .withOpacity(
                                        0.05),

                                blurRadius: 10,

                                offset:
                                    const Offset(
                                        0, 5),
                              ),
                            ],
                          ),

                          child: const Icon(

                            Icons.shopping_cart,

                            color: Colors.orange,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),

                  // BANNER UTAMA
                  Container(

                    height: 220,

                    width: double.infinity,

                    decoration: BoxDecoration(

                      borderRadius:
                          BorderRadius.circular(28),

                      image: const DecorationImage(

                        image: AssetImage(
                          "assets/images/laut.jpg",
                        ),

                        fit: BoxFit.cover,
                      ),
                    ),

                    child: Container(

                      padding: const EdgeInsets.all(25),

                      decoration: BoxDecoration(

                        borderRadius:
                            BorderRadius.circular(28),

                        color:
                            Colors.black.withOpacity(0.35),
                      ),

                      child: Column(

                        crossAxisAlignment:
                            CrossAxisAlignment.start,

                        mainAxisAlignment:
                            MainAxisAlignment.center,

                        children: [

                          Text(

                            "Seafood Segar\nSetiap Hari",

                            style:
                                GoogleFonts.poppins(

                              color: Colors.white,

                              fontSize: 30,

                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 15),

                          Text(

                            "Pesan ikan langsung dari agen dan nelayan terpercaya Bengkalis.",

                            style:
                                GoogleFonts.poppins(

                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // STATUS NELAYAN
                  Container(

                    padding:
                        const EdgeInsets.all(
                      20,
                    ),

                    decoration:
                        BoxDecoration(

                      color: Colors.white,

                      borderRadius:
                          BorderRadius.circular(
                              24),

                      boxShadow: [

                        BoxShadow(

                          color: Colors.black
                              .withOpacity(0.05),

                          blurRadius: 12,

                          offset:
                              const Offset(
                                  0, 6),
                        ),
                      ],
                    ),

                    child: Row(

                      children: [

                        Container(

                          height: 65,
                          width: 65,

                          decoration:
                              BoxDecoration(

                            color: Colors.blue
                                .withOpacity(0.1),

                            borderRadius:
                                BorderRadius
                                    .circular(
                                        18),
                          ),

                          child: const Icon(

                            Icons.sailing,

                            color: Colors.blue,

                            size: 35,
                          ),
                        ),

                        const SizedBox(
                            width: 18),

                        Expanded(

                          child: Column(

                            crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,

                            children: [

                              Text(
                                    "Informasi Stok",
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),

                                  const SizedBox(height: 6),

                                  Text(
                                    "Stok ikan diperbarui setelah hasil tangkapan tiba di dermaga dan diterima agen.",
                                    style: GoogleFonts.poppins(
                                      color: Colors.grey,
                                      height: 1.5,
                                    ),
                                  ),

                              const SizedBox(
                                  height:
                                      6),

                              Text(
                                "Informasi Stok",
                              ),

                              Text(
                                "Stok ikan diperbarui setelah hasil tangkapan tiba di dermaga dan diterima agen.",
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  Container(

                    width: double.infinity,

                    padding:
                        const EdgeInsets.all(22),

                    decoration:
                        BoxDecoration(

                      color:
                          Colors.blue.withOpacity(0.08),

                      borderRadius:
                          BorderRadius.circular(24),
                    ),

                    child: Row(

                      children: [

                        Container(

                          height: 80,
                          width: 80,

                          decoration:
                              BoxDecoration(

                            color: Colors.white,

                            borderRadius:
                                BorderRadius.circular(
                                    20),
                          ),

                          child: const Icon(

                            Icons.set_meal,

                            size: 40,

                            color: Colors.blue,
                          ),
                        ),

                        const SizedBox(width: 18),

                        Expanded(

                          child: Column(

                            crossAxisAlignment:
                                CrossAxisAlignment.start,

                            children: [

                              Text(

                                "Tentang FreshFish",

                                style:
                                    GoogleFonts.poppins(

                                  fontWeight:
                                      FontWeight.bold,

                                  fontSize: 18,

                                  color: Colors.blue,
                                ),
                              ),

                              const SizedBox(height: 8),

                              Text(

                                "FreshFish membantu masyarakat membeli ikan segar langsung dari agen dan nelayan lokal Bengkalis dengan harga yang transparan.",

                                style:
                                    GoogleFonts.poppins(

                                  height: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),

                  // PROMO
                  Container(

                    width: double.infinity,

                    padding:
                        const EdgeInsets.all(
                      22,
                    ),

                    decoration:
                        BoxDecoration(

                      color: Colors.orange
                          .withOpacity(0.1),

                      borderRadius:
                          BorderRadius.circular(
                              24),
                    ),

                    child: Column(

                      crossAxisAlignment:
                          CrossAxisAlignment
                              .start,

                      children: [

                        Text(

                          "Promo Hari Ini 🎉",

                          style:
                              GoogleFonts
                                  .poppins(

                            fontSize: 18,

                            fontWeight:
                                FontWeight.bold,

                            color:
                                Colors.orange,
                          ),
                        ),

                        const SizedBox(
                            height: 10),

                        Text(

                          "Gratis ongkir untuk pembelian di atas Rp100.000.",

                          style:
                              GoogleFonts
                                  .poppins(

                            height: 1.6,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 100),
                ],
              ),
            ),
          ],
        ),
      ),

      bottomNavigationBar:
          BottomNavigationBar(

        currentIndex:
            currentIndex,

        type:
            BottomNavigationBarType.fixed,

        selectedItemColor:
            Colors.blue,

        unselectedItemColor:
            Colors.grey,

        onTap: (index){

          setState(() {

            currentIndex = index;
          });

          if(index == 1){

            Navigator.push(

              context,

              MaterialPageRoute(

                builder: (_) =>
                    const RiwayatPage(),
              ),
            );
          }

          if(index == 2){

            Navigator.push(

              context,

              MaterialPageRoute(

                builder: (_) =>
                    const InfoHargaPage(),
              ),
            );
          }

          if(index == 3){

            Navigator.push(

              context,

              MaterialPageRoute(

                builder: (_) =>
                    const ProfilPage(),
              ),
            );
          }
        },

        items: const [

          BottomNavigationBarItem(

            icon: Icon(Icons.home),

            label: "Beranda",
          ),

          BottomNavigationBarItem(

            icon: Icon(Icons.history),

            label: "Riwayat",
          ),

          BottomNavigationBarItem(

            icon: Icon(Icons.attach_money),

            label: "Info Harga",
          ),

          BottomNavigationBarItem(

            icon: Icon(Icons.person),

            label: "Profil",
          ),
        ],
      ),
    );
  }
}