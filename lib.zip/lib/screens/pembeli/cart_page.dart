import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import '../../services/cart_service.dart';
import 'package:intl/intl.dart';

class CartPage extends StatefulWidget {

  const CartPage({super.key});

  @override
  State<CartPage> createState() =>
      _CartPageState();
}

class _CartPageState
    extends State<CartPage> {
      final rupiah = NumberFormat.currency(
        locale: 'id_ID',
        symbol: 'Rp ',
        decimalDigits: 0,
      );

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor:
          const Color(0xFFF8FBFF),

      appBar: AppBar(

        title: Text(

          "Keranjang",

          style:
              GoogleFonts.poppins(

            fontWeight:
                FontWeight.bold,
          ),
        ),

        backgroundColor:
            Colors.orange,

        foregroundColor:
            Colors.white,
      ),

      body: CartService.cartItems.isEmpty

          ? Center(

              child: Text(

                "Keranjang masih kosong",

                style:
                    GoogleFonts.poppins(
                  fontSize: 16,
                ),
              ),
            )

          : ListView.builder(

              padding:
                  const EdgeInsets.all(
                20,
              ),

              itemCount:
                  CartService
                      .cartItems.length,

              itemBuilder:
                  (context, index){

                final item =
                    CartService
                        .cartItems[index];

                final ikan =
                    item.ikan;

                return Container(

                  margin:
                      const EdgeInsets.only(
                    bottom: 18,
                  ),

                  padding:
                      const EdgeInsets.all(
                    18,
                  ),

                  decoration:
                      BoxDecoration(

                    color: Colors.white,

                    borderRadius:
                        BorderRadius.circular(
                            22),

                    boxShadow: [

                      BoxShadow(

                        color: Colors.black
                            .withOpacity(
                                0.05),

                        blurRadius: 10,

                        offset:
                            const Offset(
                                0, 5),
                      ),
                    ],
                  ),

                  child: Row(

                    children: [

                      Container(

                        height: 80,
                        width: 80,

                        decoration:
                            BoxDecoration(

                          borderRadius:
                              BorderRadius
                                  .circular(
                                      16),

                          image:
                              DecorationImage(

                            image:
                                NetworkImage(

                              "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${ikan["foto_ikan"]}",
                            ),

                            fit: BoxFit.cover,
                          ),
                        ),
                      ),

                      const SizedBox(
                          width: 15),

                      Expanded(

                        child: Column(

                          crossAxisAlignment:
                              CrossAxisAlignment
                                  .start,

                          children: [

                            Text(

                              ikan["nama_ikan"] ?? "-",

                              style:
                                  GoogleFonts
                                      .poppins(

                                fontWeight:
                                    FontWeight
                                        .bold,

                                fontSize: 16,
                              ),
                            ),

                            const SizedBox(
                                height: 6),

                            Text(

                              rupiah.format(
                                int.tryParse(ikan["harga"].toString()) ?? 0,
                              ),

                              style: GoogleFonts.poppins(

                                color: Colors.orange,

                                fontWeight: FontWeight.bold,

                              ),

                            ),

                            const SizedBox(
                                height: 6),

                            Text(

                              "Jumlah : ${item.jumlah}",

                              style:
                                  GoogleFonts
                                      .poppins(),
                            ),
                          ],
                        ),
                      ),

                      IconButton(

                        onPressed: () async {

                        final pref =
                            await SharedPreferences.getInstance();

                        final idUser =
                            pref.getString("id_user");

                        for(var item in CartService.cartItems){

                          final ikan = item.ikan;

                          final total =
                              double.parse(
                                ikan["harga"].toString(),
                              ) * item.jumlah;

                          await http.post(

                            Uri.parse(
                              "http://192.168.1.15/appfreashfish/freashfish_api/checkout.php",
                            ),

                            body: {

                              "id_user": idUser,

                              "nama_ikan":
                                  ikan["nama_ikan"],

                              "harga":
                                  ikan["harga"]
                                      .toString(),

                              "jumlah":
                                  item.jumlah
                                      .toString(),

                              "total_harga":
                                  total.toString(),
                            },
                          );
                        }

                        CartService.cartItems.clear();

                        if (!mounted) return;

                        ScaffoldMessenger.of(context)
                            .showSnackBar(

                          SnackBar(

                            backgroundColor:
                                Colors.green,

                            content: Text(

                              "Checkout berhasil",

                              style:
                                  GoogleFonts.poppins(),
                            ),
                          ),
                        );

                        setState(() {});
                      },

                        icon: const Icon(

                          Icons.delete,

                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),

      bottomNavigationBar:
          CartService.cartItems.isEmpty

              ? null

              : Container(

                  padding:
                      const EdgeInsets.all(
                    20,
                  ),

                  decoration:
                      const BoxDecoration(

                    color: Colors.white,
                  ),

                  child: Column(

                    mainAxisSize:
                        MainAxisSize.min,

                    children: [

                      Row(

                        mainAxisAlignment:
                            MainAxisAlignment
                                .spaceBetween,

                        children: [

                          Text(

                            "Total Harga",

                            style:
                                GoogleFonts
                                    .poppins(

                              fontSize: 16,

                              fontWeight:
                                  FontWeight
                                      .bold,
                            ),
                          ),

                          Text(

                            "{CartService.totalHarga()}",

                            style:
                                GoogleFonts
                                    .poppins(

                              fontSize: 18,

                              fontWeight:
                                  FontWeight
                                      .bold,

                              color:
                                  Colors.orange,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(
                          height: 15),

                      SizedBox(

                        width: double.infinity,
                        height: 55,

                        child:
                            ElevatedButton(

                          style:
                              ElevatedButton
                                  .styleFrom(

                            backgroundColor:
                                Colors.orange,

                            shape:
                                RoundedRectangleBorder(

                              borderRadius:
                                  BorderRadius.circular(
                                      18),
                            ),
                          ),

                          onPressed: () {

                            ScaffoldMessenger.of(
                                    context)
                                .showSnackBar(

                              SnackBar(

                                backgroundColor:
                                    Colors.green,

                                content: Text(

                                  "Checkout berhasil",

                                  style:
                                      GoogleFonts
                                          .poppins(),
                                ),
                              ),
                            );
                          },

                          child: Text(

                            "CHECKOUT",

                            style:
                                GoogleFonts
                                    .poppins(

                              color:
                                  Colors.white,

                              fontWeight:
                                  FontWeight
                                      .bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}