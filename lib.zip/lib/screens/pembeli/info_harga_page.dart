import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'detail_ikan_page.dart';
import 'package:intl/intl.dart';

class InfoHargaPage extends StatefulWidget {

  const InfoHargaPage({super.key});

  @override
  State<InfoHargaPage> createState() =>
      _InfoHargaPageState();
}

class _InfoHargaPageState
    extends State<InfoHargaPage> {
      final rupiah = NumberFormat.currency(
        locale: 'id_ID',
        symbol: 'Rp ',
        decimalDigits: 0,
      );

  List ikanList = [];
  String kategoriDipilih = "Semua";

  List get ikanFilter {

  if(kategoriDipilih ==
      "Semua") {

    return ikanList;
  }

  return ikanList.where((item){

    return item["kategori"] ==
        kategoriDipilih;

  }).toList();
}
  @override
  void initState() {

    super.initState();

    getDataIkan();
  }

  Future getDataIkan() async {

  try {

    final response = await http.get(

      Uri.parse(

        "http://192.168.1.15/appfreashfish/freashfish_api/get_info_harga.php",

      ),

    );


    print("STATUS = ${response.statusCode}");
    print("BODY = ${response.body}");

    setState(() {

      ikanList = jsonDecode(response.body);

    });

  } catch (e) {

    print("ERROR = $e");

  }
}

  @override
Widget build(BuildContext context) {

  return Scaffold(

    backgroundColor: const Color(0xFFF8FBFF),

    appBar: AppBar(

      title: Text(

        "Info Harga Ikan",

        style: GoogleFonts.poppins(
          fontWeight: FontWeight.bold,
        ),
      ),

      backgroundColor: Colors.blue,
      foregroundColor: Colors.white,
    ),
    

    body: Column(

      children: [

        SizedBox(

          height: 68,

          child: ListView(

            scrollDirection: Axis.horizontal,

            padding: const EdgeInsets.symmetric(
              horizontal: 15,
              vertical: 10,
            ),

            children: [

              kategoriButton("Semua"),

              kategoriButton("Ikan Laut"),

              kategoriButton("Ikan Tawar"),

              kategoriButton("Udang"),

              kategoriButton("Kerang"),

            ],
          ),
        ),

        Expanded(

          child: ListView.builder(
            padding: const EdgeInsets.all(20),
            itemCount: ikanFilter.length,
            itemBuilder: (context, index) {

              final ikan = ikanFilter[index];

              double harga =
              double.tryParse(
                ikan["harga"].toString(),
              ) ?? 0;

              double hargaLama =
                  double.tryParse(
                    ikan["harga_lama"]?.toString() ?? "0",
                  ) ?? 0;

              String statusHarga = "STABIL";

              if (harga > hargaLama) {
                statusHarga = "NAIK";
              } else if (harga < hargaLama) {
                statusHarga = "TURUN";
              }

              return GestureDetector(

                onTap: () {

                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => DetailIkanPage(
                        ikan: ikan,
                      ),
                    ),
                  );

                },

                child: Container(

                  margin: const EdgeInsets.only(
                    bottom: 16,
                  ),

                  padding: const EdgeInsets.all(16),

                  decoration: BoxDecoration(

                    color: Colors.white,

                    borderRadius:
                        BorderRadius.circular(20),

                    boxShadow: [
                      BoxShadow(
                        color:
                            Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),

                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            ClipRRect(
                              borderRadius: BorderRadius.circular(15),
                              child: Image.network(
                                "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${ikan["foto_ikan"]}",
                                width: 110,
                                height: 110,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    width: 110,
                                    height: 110,
                                    color: Colors.grey.shade200,
                                    child: const Icon(Icons.image),
                                  );
                                },
                              ),
                            ),

                            const SizedBox(width: 15),

                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [

                                  Text(
                                    "TANGKAPAN UTAMA",
                                    style: GoogleFonts.poppins(
                                      fontSize: 10,
                                      color: Colors.grey,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),

                                  const SizedBox(height: 5),

                                  Text(
                                    ikan["nama_ikan"],
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.poppins(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),

                                  const SizedBox(height: 8),

                                  Text(
                                    "${rupiah.format(
                                      int.tryParse(ikan["harga"].toString()) ?? 0,
                                    )} /Kg",
                                    style: GoogleFonts.poppins(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),

                                  const SizedBox(height: 6),

                                  Row(
                                    children: [
                                      Icon(
                                        statusHarga == "NAIK"
                                            ? Icons.arrow_upward
                                            : statusHarga == "TURUN"
                                                ? Icons.arrow_downward
                                                : Icons.remove,
                                        size: 16,
                                        color: statusHarga == "NAIK"
                                            ? Colors.red
                                            : statusHarga == "TURUN"
                                                ? Colors.green
                                                : Colors.orange,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        statusHarga,
                                        style: GoogleFonts.poppins(
                                          color: statusHarga == "NAIK"
                                              ? Colors.red
                                              : statusHarga == "TURUN"
                                                  ? Colors.green
                                                  : Colors.orange,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),

                                  const SizedBox(height: 8),

                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 5,
                                    ),
                                    decoration: BoxDecoration(
                                      color: ikan["status_tersedia"] == "ready"
                                          ? Colors.green.withOpacity(0.1)
                                          : Colors.orange.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      ikan["status_tersedia"] == "ready"
                                          ? "READY"
                                          : "PRE ORDER",
                                      style: GoogleFonts.poppins(
                                        color: ikan["status_tersedia"] == "ready"
                                            ? Colors.green
                                            : Colors.orange,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 15),

                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius:
                              BorderRadius.circular(15),
                          border: Border.all(
                            color: Colors.grey.shade200,
                          ),
                        ),
                        child: Row(
                          children: [

                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [

                                  Text(
                                    "LOKASI",
                                    style: GoogleFonts.poppins(
                                      fontSize: 10,
                                      color: Colors.grey,
                                    ),
                                  ),

                                  Text(
                                    ikan["alamat"] ?? "-",
                                    style: GoogleFonts.poppins(
                                      fontWeight:
                                          FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [

                                  Text(
                                    "AGEN",
                                    style: GoogleFonts.poppins(
                                      fontSize: 10,
                                      color: Colors.grey,
                                    ),
                                  ),

                                  Text(
                                    ikan["nama_lengkap"] ?? "-",
                                    style: GoogleFonts.poppins(
                                      fontWeight:
                                          FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    ),
  );
}

    Widget kategoriButton(String kategori) {

    bool isSelected =
        kategoriDipilih == kategori;

    return GestureDetector(

      onTap: () {

        setState(() {

          kategoriDipilih = kategori;

        });
      },

      child: AnimatedContainer(

        duration:
            const Duration(milliseconds: 250),

        margin:
            const EdgeInsets.only(right: 10),

        padding:
            const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 12,
        ),

        decoration: BoxDecoration(

          color: isSelected
              ? Colors.blue
              : Colors.white,

          borderRadius:
              BorderRadius.circular(16),

          border: Border.all(
            color: isSelected
                ? Colors.blue
                : Colors.grey.shade300,
          ),

          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: Colors.blue
                        .withOpacity(0.20),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),

        child: Text(

          kategori,

          style: GoogleFonts.poppins(

            fontSize: 14,

            fontWeight:
                FontWeight.w600,

            color: isSelected
                ? Colors.white
                : Colors.black87,
          ),
        ),
      ),
    );
  }
}

