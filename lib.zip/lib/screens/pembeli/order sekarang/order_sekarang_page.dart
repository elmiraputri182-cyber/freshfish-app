import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../../services/pesanan_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── Design Tokens ───────────────────────────────────────────────────────────
const _kPrimary    = Color(0xFF0077B6); // deep ocean blue
const _kAccent     = Color(0xFF00B4D8); // bright aqua
const _kSurface    = Color(0xFFF0F7FF); // pale sky
const _kCardBg     = Colors.white;
const _kOrange     = Color(0xFFF77F00); // vibrant order CTA
const _kTextDark   = Color(0xFF023E58);
const _kTextLight  = Color(0xFF6B9DB8);
const _kDivider    = Color(0xFFDEEDF7);
const _kRadius     = 18.0;

class OrderSekarangPage extends StatefulWidget {
  final Map ikan;
  
  const OrderSekarangPage({
    super.key,
    required this.ikan,
  });

  @override
  State<OrderSekarangPage> createState() => _OrderSekarangPageState();
}

class _OrderSekarangPageState extends State<OrderSekarangPage> {
  final TextEditingController jumlahKg = TextEditingController();

  String metodePengambilan = "cod";
  String metodePembayaran  = "cod";

  double total    = 0;
  bool isLoading  = false;

  void hitungTotal() {
    final harga = double.tryParse(widget.ikan["harga"].toString()) ?? 0;
    final kg    = double.tryParse(jumlahKg.text) ?? 0;
    setState(() => total = harga * kg);
  }

  // ── Reusable section label ────────────────────────────────────────────────
  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(
          text,
          style: GoogleFonts.poppins(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: _kTextLight,
            letterSpacing: 0.6,
          ),
        ),
      );

  // ── Styled card wrapper ───────────────────────────────────────────────────
  Widget _card({required Widget child, EdgeInsets? padding}) => Container(
        width: double.infinity,
        padding: padding ?? const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _kCardBg,
          borderRadius: BorderRadius.circular(_kRadius),
          boxShadow: [
            BoxShadow(
              color: _kPrimary.withOpacity(0.07),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: child,
      );

  // ── Delivery option tile ──────────────────────────────────────────────────
  Widget _deliveryOption({
    required String value,
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    final selected = metodePengambilan == value;
    return GestureDetector(
      onTap: () => setState(() => metodePengambilan = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? _kPrimary.withOpacity(0.07) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? _kPrimary : _kDivider,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: selected ? _kPrimary : _kSurface,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon,
                  size: 20,
                  color: selected ? Colors.white : _kTextLight),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        color: selected ? _kPrimary : _kTextDark,
                      )),
                  Text(subtitle,
                      style: GoogleFonts.poppins(
                        fontSize: 11,
                        color: _kTextLight,
                      )),
                ],
              ),
            ),
            if (selected)
              const Icon(Icons.check_circle_rounded,
                  color: _kPrimary, size: 20),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final harga = double.tryParse(widget.ikan["harga"].toString()) ?? 0;

    return Scaffold(
      backgroundColor: _kSurface,
      // ── AppBar ────────────────────────────────────────────────────────────
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                    color: _kPrimary.withOpacity(0.1),
                    blurRadius: 8)
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _kTextDark, size: 18),
          ),
        ),
        title: Text(
          "Buat Pesanan",
          style: GoogleFonts.poppins(
            color: _kTextDark,
            fontWeight: FontWeight.w700,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 120),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // ── Hero foto ─────────────────────────────────────────────────
            ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Stack(
                children: [
                  Image.network(
                    "http://192.168.1.15/appfreashfish/freashfish_api/uploads/${widget.ikan["foto_ikan"]}",
                    height: 220,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 220,
                      color: _kDivider,
                      child: const Icon(Icons.image_not_supported,
                          color: _kTextLight, size: 50),
                    ),
                  ),
                  // subtle gradient overlay
                  Positioned(
                    bottom: 0, left: 0, right: 0,
                    child: Container(
                      height: 80,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [
                            _kTextDark.withOpacity(0.55),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  // stok badge
                  Positioned(
                    bottom: 14, left: 14,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 7, height: 7,
                            decoration: const BoxDecoration(
                              color: Color(0xFF2EC86A),
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 5),
                          Text("Tersedia",
                              style: GoogleFonts.poppins(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: _kTextDark)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Info ikan ─────────────────────────────────────────────────
            _card(
              padding: const EdgeInsets.all(18),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.ikan["nama_ikan"] ?? "-",
                          style: GoogleFonts.poppins(
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                            color: _kTextDark,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "Ikan segar langsung dari nelayan",
                          style: GoogleFonts.poppins(
                              fontSize: 12, color: _kTextLight),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        NumberFormat.currency(
                          locale: 'id_ID',
                          symbol: 'Rp ',
                          decimalDigits: 0,
                        ).format(harga),
                        style: GoogleFonts.poppins(
                          color: _kPrimary,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        "per kilogram",
                        style: GoogleFonts.poppins(
                            fontSize: 11, color: _kTextLight),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // ── Jumlah pesanan ────────────────────────────────────────────
            _sectionLabel("JUMLAH PESANAN"),
            _card(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 6),
              child: TextField(
                controller: jumlahKg,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: _kTextDark),
                onChanged: (_) => hitungTotal(),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  labelText: "Masukkan berat (kg)",
                  labelStyle: GoogleFonts.poppins(
                      fontSize: 14, color: _kTextLight),
                  prefixIcon: const Icon(Icons.scale_rounded,
                      color: _kAccent),
                  suffix: Text(
                    "KG",
                    style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w700,
                        color: _kPrimary,
                        fontSize: 13),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // ── Metode pengambilan ────────────────────────────────────────
            _sectionLabel("METODE PENGAMBILAN"),
            _card(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  _deliveryOption(
                    value: "cod",
                    icon: Icons.delivery_dining_rounded,
                    title: "Antar ke Lokasi (COD)",
                    subtitle: "Kami antar ke alamat kamu",
                  ),
                  const SizedBox(height: 8),
                  _deliveryOption(
                    value: "ambil_ditempat",
                    icon: Icons.storefront_rounded,
                    title: "Ambil di Tempat",
                    subtitle: "Datang langsung ke kios agen",
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // ── Metode pembayaran ─────────────────────────────────────────
            _sectionLabel("METODE PEMBAYARAN"),
            _card(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 6),
              child: DropdownButtonFormField<String>(
                value: metodePembayaran,
                icon: const Icon(Icons.keyboard_arrow_down_rounded,
                    color: _kPrimary),
                style: GoogleFonts.poppins(
                    color: _kTextDark,
                    fontWeight: FontWeight.w600,
                    fontSize: 14),
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.payment_rounded,
                      color: _kAccent),
                ),
                items: const [
                  DropdownMenuItem(
                      value: "cod",
                      child: Text("COD — Bayar di Tempat")),
                       DropdownMenuItem(
                      value: "cash",
                      child: Text("Cash — Bayar Tunai")),
                  DropdownMenuItem(
                      value: "dana", child: Text("Mbanking / Ewallet")),
                ],
                onChanged: (value) =>
                    setState(() => metodePembayaran = value!),
              ),
            ),

            const SizedBox(height: 24),

            // ── Ringkasan harga ───────────────────────────────────────────
            _sectionLabel("RINGKASAN HARGA"),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [_kPrimary, _kAccent],
                ),
                borderRadius: BorderRadius.circular(_kRadius),
                boxShadow: [
                  BoxShadow(
                    color: _kPrimary.withOpacity(0.35),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // breakdown baris
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Harga / kg",
                          style: GoogleFonts.poppins(
                              color: Colors.white60,
                              fontSize: 13)),
                      Text(
                        NumberFormat.currency(
                          locale: 'id_ID',
                          symbol: 'Rp ',
                          decimalDigits: 0,
                        ).format(harga),
                        style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 13),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Jumlah",
                          style: GoogleFonts.poppins(
                              color: Colors.white60,
                              fontSize: 13)),
                      Text(
                        jumlahKg.text.isEmpty
                            ? "0 kg"
                            : "${jumlahKg.text} kg",
                        style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 13),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Divider(
                        color: Colors.white.withOpacity(0.25),
                        thickness: 1),
                  ),
                  Text(
                    "TOTAL PEMBAYARAN",
                    style: GoogleFonts.poppins(
                      color: Colors.white70,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    NumberFormat.currency(
                      locale: 'id_ID',
                      symbol: 'Rp ',
                      decimalDigits: 0,
                    ).format(total),
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: FontWeight.w800,
                      height: 1.1,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),

      // ── Floating CTA button ───────────────────────────────────────────────
      bottomNavigationBar: Container(
        padding:
            const EdgeInsets.fromLTRB(20, 12, 20, 28),
        decoration: BoxDecoration(
          color: _kSurface,
          boxShadow: [
            BoxShadow(
              color: _kPrimary.withOpacity(0.08),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: SizedBox(
          height: 58,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _kOrange,
              foregroundColor: Colors.white,
              elevation: 0,
              shadowColor: _kOrange.withOpacity(0.4),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            onPressed: isLoading
                ? null
                : () async {
                    if (jumlahKg.text.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            "Masukkan jumlah kg terlebih dahulu",
                            style: GoogleFonts.poppins(),
                          ),
                          backgroundColor: Colors.redAccent,
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                      );
                      return;
                    }

                    setState(() => isLoading = true);

                    final prefs = await SharedPreferences.getInstance();

                    final idUser = prefs.getString("id_user") ?? "";

                    print("================================");
                    print(widget.ikan);
                    print("ID PEMBELI = $idUser");
                    print("ID AGEN = ${widget.ikan["id_user"]}");
                    print("ID IKAN = ${widget.ikan["id_ikan"]}");
                    print("NAMA IKAN = ${widget.ikan["nama_ikan"]}");
                    print("================================");

                    final sukses = await PesananService.tambahPesanan(
                      idPembeli: idUser,
                      idAgen: widget.ikan["id_user"].toString(),
                      idIkan: widget.ikan["id_ikan"].toString(),
                      jumlahKg: jumlahKg.text,
                      metodePengambilan: metodePengambilan,
                      metodePembayaran: metodePembayaran,
                      totalBayar: total.toString(),
                    );
                    print("ID PEMBELI = $idUser");
                    print("ID AGEN = ${widget.ikan["id_user"]}");
                    print("ID IKAN = ${widget.ikan["id_ikan"]}");
                    print("NAMA IKAN = ${widget.ikan["nama_ikan"]}");

                    setState(() => isLoading = false);

                    if (sukses) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Row(
                            children: [
                              const Icon(Icons.check_circle,
                                  color: Colors.white),
                              const SizedBox(width: 8),
                              Text("Pesanan berhasil dibuat!",
                                  style: GoogleFonts.poppins()),
                            ],
                          ),
                          backgroundColor: const Color(0xFF2EC86A),
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                      );
                      Navigator.pop(context);
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Row(
                            children: [
                              const Icon(Icons.error_outline,
                                  color: Colors.white),
                              const SizedBox(width: 8),
                              Text("Pesanan gagal, coba lagi",
                                  style: GoogleFonts.poppins()),
                            ],
                          ),
                          backgroundColor: Colors.redAccent,
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                      );
                    }
                  },
            child: isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.5,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.shopping_bag_rounded, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        "Pesan Sekarang",
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}