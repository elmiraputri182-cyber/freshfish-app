class Api {

  static const String baseUrl =
    "http://192.168.1.15/appfreashfish/freashfish_api";

}