import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'screens/auth/login_page.dart';
import 'screens/pembeli/home_page.dart';
import 'package:intl/date_symbol_data_local.dart';


Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();

  await initializeDateFormatting('id_ID', null);

  runApp(
    const MyApp(),
  );
}

class MyApp extends StatelessWidget {

  const MyApp({super.key});

  Future<bool> checkLogin() async {

    final pref =
        await SharedPreferences.getInstance();

    final isLogin =
    pref.getBool("isLogin");

    return isLogin == true;
  }

  @override
  Widget build(BuildContext context) {

    return MaterialApp(

      debugShowCheckedModeBanner: false,

      home: FutureBuilder(

        future: checkLogin(),

        builder: (context, snapshot){

          if(snapshot.connectionState ==
              ConnectionState.waiting){

            return const Scaffold(

              body: Center(
                child:
                    CircularProgressIndicator(),
              ),
            );
          }

          if(snapshot.data == true){

            return const HomePage();
          }

          return const LoginPage();
        },
      ),
    );
  }
}